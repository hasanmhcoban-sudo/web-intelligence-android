"""Deterministic normalization and validation for extracted records."""
from dataclasses import replace
from datetime import datetime
import json
import unicodedata
from urllib.parse import urlsplit

ALLOWED_SCHEMES = {"http", "https"}
ALLOWED_STATUSES = {"valid", "empty", "invalid", "partial"}

def normalize_text(value, max_length=None):
    if value is None:
        result = ""
    else:
        result = unicodedata.normalize("NFC", str(value))
        result = " ".join(result.replace("\x00", " ").split())
    return result[:max_length] if max_length is not None else result

def validate_source_url(value):
    if not isinstance(value, str) or len(value) > 8192:
        raise ValueError("source_url must be a string no longer than 8192 characters")
    parsed = urlsplit(value)
    if parsed.scheme.lower() not in ALLOWED_SCHEMES or not parsed.hostname:
        raise ValueError("source_url must be an absolute HTTP(S) URL")
    if parsed.username or parsed.password:
        raise ValueError("source_url must not contain embedded credentials")
    return value

def normalize_metadata(value):
    if value is None:
        value = {}
    if not isinstance(value, dict):
        raise ValueError("metadata must be a mapping")
    # JSON round-trip guarantees persistence-safe values and rejects arbitrary objects.
    encoded = json.dumps(value, ensure_ascii=False, default=None)
    if len(encoded.encode("utf-8")) > 1_000_000:
        raise ValueError("metadata exceeds 1 MB")
    return json.loads(encoded)

def normalize_record(record):
    """Return a normalized copy; original raw HTML remains separately archived."""
    source_url = validate_source_url(record.source_url)
    if not isinstance(record.content_hash, str) or len(record.content_hash) != 64:
        raise ValueError("content_hash must be a 64-character SHA-256 hex digest")
    try:
        int(record.content_hash, 16)
    except ValueError as exc:
        raise ValueError("content_hash must be hexadecimal") from exc
    try:
        timestamp = datetime.fromisoformat(record.collected_at.replace("Z", "+00:00"))
    except (AttributeError, ValueError) as exc:
        raise ValueError("collected_at must be an ISO-8601 timestamp") from exc
    if timestamp.tzinfo is None:
        raise ValueError("collected_at must include a timezone")
    status = record.status
    if status not in ALLOWED_STATUSES:
        raise ValueError(f"Unsupported record status: {status}")
    metadata = normalize_metadata(record.metadata)
    metadata.setdefault("normalization", {
        "unicode": "NFC",
        "whitespace": "collapsed",
        "normalizer_version": "1.0",
    })
    return replace(
        record,
        source_url=source_url,
        title=normalize_text(record.title, 1000),
        text=normalize_text(record.text, 2_000_000),
        metadata=metadata,
    )
