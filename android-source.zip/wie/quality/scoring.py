def quality_score(completeness: float, validation: float, source_reliability: float,
                  uniqueness: float, freshness: float) -> float:
    """Weighted quality score; inputs must be normalized to 0..100."""
    values = [completeness, validation, source_reliability, uniqueness, freshness]
    if any(not isinstance(v, (int, float)) or v < 0 or v > 100 for v in values):
        raise ValueError("All quality dimensions must be numeric values between 0 and 100.")
    return round(
        0.30 * completeness
        + 0.25 * validation
        + 0.20 * source_reliability
        + 0.15 * uniqueness
        + 0.10 * freshness,
        2,
    )
