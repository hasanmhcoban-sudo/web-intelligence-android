import argparse, asyncio
from datetime import datetime, timezone
from pathlib import Path
from urllib.parse import urlparse
from .config import load_config
from .fetchers.http import fetch_http
from .extract.html import extract_page
from .models import ExtractedRecord
from .quality.hashing import sha256_text
from .storage.db import save_record
from .quality.normalize import normalize_record
from .evidence.chain import append_event
from .storage.export import export_jsonl, export_csv, export_xlsx
from .policy.robots import allowed_by_robots

def validate_url(url):
    p = urlparse(url)
    if p.scheme not in ("http", "https") or not p.netloc:
        raise ValueError("Only absolute http:// or https:// URLs are accepted.")
    return url

async def run_fetch(args):
    cfg = load_config(args.config)
    url = validate_url(args.url)
    if cfg["respect_robots_txt"]:
        allowed = await allowed_by_robots(url, cfg["user_agent"], cfg["timeout_seconds"])
        if not allowed:
            raise RuntimeError("robots.txt disallows this URL or policy could not be verified.")
    delay = float(cfg["request_delay_seconds"])
    if delay:
        await asyncio.sleep(delay)
    if args.mode == "browser":
        from .fetchers.browser import fetch_browser
        html, final_url, status = await fetch_browser(url, cfg)
    else:
        html, final_url, status = await fetch_http(url, cfg)
    extracted = extract_page(html)
    title, text = extracted['title'], extracted['text']
    record = ExtractedRecord(
        source_url=final_url,
        collected_at=datetime.now(timezone.utc).isoformat(),
        title=title,
        text=text,
        content_hash=sha256_text(html),
        status="valid" if title or text else "empty",
        metadata={"http_status": status, "mode": args.mode, "raw_html_saved": True, "page_metadata": extracted["metadata"], "jsonld": extracted["jsonld"], "structured_entities": extracted.get("structured_entities", [])}
    )
    record = normalize_record(record)
    raw_dir = Path(cfg["raw_dir"])
    raw_dir.mkdir(parents=True, exist_ok=True)
    raw_path = raw_dir / f"{record.content_hash}.html"
    raw_path.write_text(html, encoding="utf-8")
    inserted = save_record(cfg["database_path"], record)
    append_event(
        cfg["database_path"], final_url, "page_collected",
        {"content_hash": record.content_hash, "http_status": status,
         "record_inserted": inserted, "raw_archive": str(raw_path)},
    )
    state = "Saved" if inserted else "Duplicate skipped"
    print(f"{state}: {final_url}\nTitle: {title}\nHash: {record.content_hash}\nRaw: {raw_path}")

def main():
    parser = argparse.ArgumentParser(prog="wie")
    sub = parser.add_subparsers(dest="command", required=True)
    f = sub.add_parser("fetch", help="Fetch one permitted public URL")
    f.add_argument("url")
    f.add_argument("--mode", choices=["http", "browser"], default="http")
    f.add_argument("--config", default="config/settings.yaml")
    c = sub.add_parser("crawl", help="Crawl same-origin pages with depth/page limits")
    c.add_argument("url")
    c.add_argument("--max-pages", type=int, default=30)
    c.add_argument("--max-depth", type=int, default=2)
    c.add_argument("--no-sitemap", action="store_true")
    c.add_argument("--engine", choices=["httpx", "scrapy"], default="httpx")
    c.add_argument("--run-id", default=None, help="Stable crawl run ID; save it to resume later")
    c.add_argument("--resume", action="store_true", help="Resume an existing SQLite crawl run")
    c.add_argument("--config", default="config/settings.yaml")
    d = sub.add_parser("api-discover", help="Discover public API documentation links")
    d.add_argument("url")
    d.add_argument("--fetch-specs", action="store_true",
                   help="Fetch and parse explicitly advertised same-origin API specs")
    d.add_argument("--config", default="config/settings.yaml")
    a = sub.add_parser("profile", help="Profile collected records and data quality")
    a.add_argument("--config", default="config/settings.yaml")
    e = sub.add_parser("export", help="Export SQLite records to JSONL")
    e.add_argument("--format", choices=["jsonl", "csv", "xlsx"], default="jsonl")
    e.add_argument("--config", default="config/settings.yaml")
    args = parser.parse_args()
    if args.command == "fetch":
        asyncio.run(run_fetch(args))
    elif args.command == "crawl":
        from .crawl import crawl_site
        if args.max_pages < 1 or args.max_depth < 0:
            parser.error("--max-pages must be >=1 and --max-depth must be >=0")
        cfg = load_config(args.config)
        if args.engine == "scrapy":
            from .adapters.scrapy_adapter import run_scrapy_crawl
            run_scrapy_crawl(args.url, cfg, args.max_pages, args.max_depth)
            print("Scrapy crawl finished.")
        else:
            result = asyncio.run(crawl_site(
                args.url, cfg, args.max_pages, args.max_depth,
                not args.no_sitemap, run_id=args.run_id, resume=args.resume
            ))
            import json
            print(json.dumps(result, ensure_ascii=False, indent=2))
    elif args.command == "api-discover":
        asyncio.run(run_api_discovery(args))
    elif args.command == "profile":
        import json
        from .analytics.profile import profile_database
        cfg = load_config(args.config)
        print(json.dumps(profile_database(cfg["database_path"]), ensure_ascii=False, indent=2))
    else:
        cfg = load_config(args.config)
        extension = args.format
        out = str(Path(cfg["export_dir"]) / f"records.{extension}")
        exporters = {"jsonl": export_jsonl, "csv": export_csv, "xlsx": export_xlsx}
        exporters[args.format](cfg["database_path"], out)
        print(f"Exported: {out}")

if __name__ == "__main__":
    main()
