"""Content snapshots and change history for pages collected over time."""
from datetime import datetime, timezone
import difflib
import sqlite3
from .db import connect

def _history_connect(path: str):
    con = sqlite3.connect(path)
    con.row_factory = sqlite3.Row
    return con

def initialize_history(path: str):
    con = connect(path)
    try:
        con.executescript("""
        CREATE TABLE IF NOT EXISTS page_snapshots (
            id INTEGER PRIMARY KEY,
            source_url TEXT NOT NULL,
            collected_at TEXT NOT NULL,
            content_hash TEXT NOT NULL,
            title TEXT,
            text TEXT,
            UNIQUE(source_url, content_hash)
        );
        CREATE INDEX IF NOT EXISTS idx_snapshots_url_time
            ON page_snapshots(source_url, collected_at);
        """)
        con.commit()
    finally:
        con.close()

def save_snapshot(path: str, source_url: str, content_hash: str,
                  title: str, text: str, collected_at: str | None = None) -> bool:
    initialize_history(path)
    timestamp = collected_at or datetime.now(timezone.utc).isoformat()
    con = connect(path)
    try:
        cur = con.execute(
            """INSERT OR IGNORE INTO page_snapshots
               (source_url,collected_at,content_hash,title,text)
               VALUES(?,?,?,?,?)""",
            (source_url, timestamp, content_hash, title, text),
        )
        con.commit()
        return cur.rowcount == 1
    finally:
        con.close()

def list_snapshots(path: str, source_url: str, limit: int = 20):
    initialize_history(path)
    con = _history_connect(path)
    try:
        rows = con.execute(
            """SELECT id,source_url,collected_at,content_hash,title
               FROM page_snapshots WHERE source_url=?
               ORDER BY collected_at DESC,id DESC LIMIT ?""",
            (source_url, max(1, min(int(limit), 500))),
        ).fetchall()
        return [dict(row) for row in rows]
    finally:
        con.close()

def diff_snapshots(path: str, older_id: int, newer_id: int) -> dict:
    initialize_history(path)
    con = _history_connect(path)
    try:
        rows = con.execute(
            "SELECT * FROM page_snapshots WHERE id IN (?,?)",
            (older_id, newer_id),
        ).fetchall()
        by_id = {row["id"]: row for row in rows}
        if older_id not in by_id or newer_id not in by_id:
            raise ValueError("Snapshot ID not found.")
        old, new = by_id[older_id], by_id[newer_id]
        if old["source_url"] != new["source_url"]:
            raise ValueError("Snapshots must belong to the same source URL.")
        old_lines = (old["text"] or "").splitlines()
        new_lines = (new["text"] or "").splitlines()
        diff = list(difflib.unified_diff(
            old_lines, new_lines,
            fromfile=old["collected_at"], tofile=new["collected_at"],
            lineterm="",
        ))
        return {
            "source_url": old["source_url"],
            "older_hash": old["content_hash"],
            "newer_hash": new["content_hash"],
            "changed": old["content_hash"] != new["content_hash"],
            "diff": diff,
        }
    finally:
        con.close()
