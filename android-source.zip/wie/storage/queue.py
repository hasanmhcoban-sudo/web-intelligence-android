"""SQLite-backed durable crawl queue with crash recovery."""
from datetime import datetime, timezone
import sqlite3

def _now():
    return datetime.now(timezone.utc).isoformat()

def _connect(path):
    con = sqlite3.connect(path, timeout=30)
    con.row_factory = sqlite3.Row
    con.execute("PRAGMA busy_timeout=30000")
    return con

def initialize_queue(path: str):
    con = _connect(path)
    try:
        con.executescript("""
        CREATE TABLE IF NOT EXISTS crawl_runs (
            run_id TEXT PRIMARY KEY,
            start_url TEXT NOT NULL,
            created_at TEXT NOT NULL,
            updated_at TEXT NOT NULL,
            status TEXT NOT NULL DEFAULT 'running'
        );
        CREATE TABLE IF NOT EXISTS crawl_jobs (
            id INTEGER PRIMARY KEY,
            run_id TEXT NOT NULL,
            url TEXT NOT NULL,
            depth INTEGER NOT NULL,
            status TEXT NOT NULL DEFAULT 'pending',
            attempts INTEGER NOT NULL DEFAULT 0,
            last_error TEXT,
            created_at TEXT NOT NULL,
            updated_at TEXT NOT NULL,
            UNIQUE(run_id, url),
            FOREIGN KEY(run_id) REFERENCES crawl_runs(run_id)
        );
        CREATE INDEX IF NOT EXISTS idx_crawl_jobs_state
            ON crawl_jobs(run_id, status, id);
        """)
        con.commit()
    finally:
        con.close()

def create_run(path: str, run_id: str, start_url: str):
    initialize_queue(path)
    con = _connect(path)
    try:
        now = _now()
        con.execute(
            "INSERT INTO crawl_runs(run_id,start_url,created_at,updated_at,status) VALUES(?,?,?,?,?)",
            (run_id, start_url, now, now, "running"),
        )
        con.execute(
            """INSERT OR IGNORE INTO crawl_jobs
               (run_id,url,depth,status,attempts,created_at,updated_at)
               VALUES(?,?,0,'pending',0,?,?)""",
            (run_id, start_url, now, now),
        )
        con.commit()
    finally:
        con.close()

def run_exists(path: str, run_id: str) -> bool:
    initialize_queue(path)
    con = _connect(path)
    try:
        return con.execute("SELECT 1 FROM crawl_runs WHERE run_id=?", (run_id,)).fetchone() is not None
    finally:
        con.close()

def get_run(path: str, run_id: str):
    initialize_queue(path)
    con = _connect(path)
    try:
        row = con.execute("SELECT * FROM crawl_runs WHERE run_id=?", (run_id,)).fetchone()
        return dict(row) if row else None
    finally:
        con.close()

def enqueue_jobs(path: str, run_id: str, jobs):
    initialize_queue(path)
    con = _connect(path)
    try:
        now = _now()
        inserted = 0
        for url, depth in jobs:
            cur = con.execute(
                """INSERT OR IGNORE INTO crawl_jobs
                   (run_id,url,depth,status,attempts,created_at,updated_at)
                   VALUES(?,?,?,'pending',0,?,?)""",
                (run_id, url, int(depth), now, now),
            )
            inserted += cur.rowcount
        con.execute("UPDATE crawl_runs SET updated_at=?,status='running' WHERE run_id=?",
                    (now, run_id))
        con.commit()
        return inserted
    finally:
        con.close()

def recover_interrupted_jobs(path: str, run_id: str):
    """A process crash leaves in_progress rows; make them claimable again."""
    con = _connect(path)
    try:
        now = _now()
        cur = con.execute(
            """UPDATE crawl_jobs SET status='pending',updated_at=?,
               last_error=COALESCE(last_error,'Recovered after interrupted process')
               WHERE run_id=? AND status='in_progress'""",
            (now, run_id),
        )
        con.commit()
        return cur.rowcount
    finally:
        con.close()

def claim_next_job(path: str, run_id: str):
    con = _connect(path)
    try:
        con.execute("BEGIN IMMEDIATE")
        row = con.execute(
            """SELECT id,url,depth FROM crawl_jobs
               WHERE run_id=? AND status='pending' ORDER BY id LIMIT 1""",
            (run_id,),
        ).fetchone()
        if not row:
            con.commit()
            return None
        now = _now()
        con.execute(
            """UPDATE crawl_jobs SET status='in_progress',attempts=attempts+1,
               updated_at=? WHERE id=?""",
            (now, row["id"]),
        )
        con.commit()
        return dict(row)
    finally:
        con.close()

def finish_job(path: str, job_id: int, status: str, error: str | None = None):
    if status not in {"done", "error", "blocked"}:
        raise ValueError("Invalid terminal job status")
    con = _connect(path)
    try:
        con.execute(
            "UPDATE crawl_jobs SET status=?,last_error=?,updated_at=? WHERE id=?",
            (status, (error or "")[:500] or None, _now(), job_id),
        )
        con.commit()
    finally:
        con.close()

def queue_stats(path: str, run_id: str):
    con = _connect(path)
    try:
        rows = con.execute(
            "SELECT status,COUNT(*) AS n FROM crawl_jobs WHERE run_id=? GROUP BY status",
            (run_id,),
        ).fetchall()
        result = {k: 0 for k in ("pending", "in_progress", "done", "error", "blocked")}
        result.update({r["status"]: r["n"] for r in rows})
        return result
    finally:
        con.close()

def set_run_status(path: str, run_id: str, status: str):
    if status not in {"running", "completed", "paused", "failed"}:
        raise ValueError("Invalid run status")
    con = _connect(path)
    try:
        con.execute("UPDATE crawl_runs SET status=?,updated_at=? WHERE run_id=?",
                    (status, _now(), run_id))
        con.commit()
    finally:
        con.close()
