from pathlib import Path
import csv
import json
import sqlite3

COLUMNS = ["source_url", "collected_at", "title", "text", "content_hash", "status", "metadata_json"]

def _rows(db_path: str):
    con = sqlite3.connect(db_path)
    try:
        return con.execute(
            "SELECT source_url,collected_at,title,text,content_hash,status,metadata_json "
            "FROM records ORDER BY id"
        ).fetchall()
    finally:
        con.close()

def export_jsonl(db_path: str, output_path: str):
    Path(output_path).parent.mkdir(parents=True, exist_ok=True)
    with open(output_path, "w", encoding="utf-8") as handle:
        for row in _rows(db_path):
            item = dict(zip(COLUMNS, row))
            item["metadata"] = json.loads(item.pop("metadata_json") or "{}")
            handle.write(json.dumps(item, ensure_ascii=False) + "\n")

def export_csv(db_path: str, output_path: str):
    Path(output_path).parent.mkdir(parents=True, exist_ok=True)
    with open(output_path, "w", encoding="utf-8-sig", newline="") as handle:
        writer = csv.writer(handle)
        writer.writerow(COLUMNS)
        writer.writerows(_rows(db_path))

def export_xlsx(db_path: str, output_path: str):
    try:
        from openpyxl import Workbook
    except ImportError as exc:
        raise RuntimeError("XLSX export requires openpyxl (free/open source).") from exc
    Path(output_path).parent.mkdir(parents=True, exist_ok=True)
    workbook = Workbook(write_only=True)
    sheet = workbook.create_sheet("Records")
    sheet.append(COLUMNS)
    for row in _rows(db_path):
        sheet.append(list(row))
    workbook.save(output_path)
