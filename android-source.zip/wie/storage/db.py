from pathlib import Path
import sqlite3

SCHEMA = """
CREATE TABLE IF NOT EXISTS records (
 id INTEGER PRIMARY KEY,
 source_url TEXT NOT NULL,
 collected_at TEXT NOT NULL,
 title TEXT,
 text TEXT,
 content_hash TEXT NOT NULL,
 status TEXT NOT NULL,
 metadata_json TEXT
);
CREATE UNIQUE INDEX IF NOT EXISTS idx_records_url_hash ON records(source_url, content_hash);
CREATE INDEX IF NOT EXISTS idx_records_hash ON records(content_hash);
"""

def connect(path: str):
    p = Path(path)
    p.parent.mkdir(parents=True, exist_ok=True)
    con = sqlite3.connect(p)
    con.executescript(SCHEMA)
    return con

def save_record(path: str, record) -> bool:
    """Save a record. Return False when the same URL+content hash already exists."""
    con = connect(path)
    try:
        cur = con.execute(
            """INSERT OR IGNORE INTO records
            (source_url,collected_at,title,text,content_hash,status,metadata_json)
            VALUES(?,?,?,?,?,?,?)""",
            (record.source_url, record.collected_at, record.title, record.text,
             record.content_hash, record.status,
             __import__("json").dumps(record.metadata or {}, ensure_ascii=False))
        )
        con.commit()
        return cur.rowcount == 1
    finally:
        con.close()
