import asyncio
from datetime import datetime, timezone
from pathlib import Path
from urllib.parse import urljoin, urlparse, urldefrag
import uuid
from bs4 import BeautifulSoup

from .fetchers.http import fetch_http
from .extract.html import extract_page
from .models import ExtractedRecord
from .quality.hashing import sha256_text
from .quality.normalize import normalize_record
from .evidence.chain import append_event
from .storage.db import save_record
from .storage.history import save_snapshot
from .storage.queue import (
    create_run, run_exists, get_run, enqueue_jobs, recover_interrupted_jobs,
    claim_next_job, finish_job, queue_stats, set_run_status,
)
from .policy.robots import load_robots_policy
from .policy.url_safety import validate_public_http_url, UnsafeURLError
from .discovery.sitemap import discover_sitemap_urls
from .quality.scoring import quality_score

def normalize_url(url: str) -> str:
    url, _ = urldefrag(url)
    p = urlparse(url)
    if p.scheme not in ("http", "https") or not p.netloc:
        return ""
    return url

def same_origin(a: str, b: str) -> bool:
    x, y = urlparse(a), urlparse(b)
    return (x.scheme, x.netloc) == (y.scheme, y.netloc)

def extract_links(html: str, page_url: str, root_url: str) -> list[str]:
    soup = BeautifulSoup(html, "html.parser")
    results = []
    for tag in soup.find_all("a", href=True):
        candidate = normalize_url(urljoin(page_url, tag["href"]))
        if candidate and same_origin(candidate, root_url):
            results.append(candidate)
    return list(dict.fromkeys(results))

async def crawl_site(start_url: str, cfg: dict, max_pages: int = 30,
                     max_depth: int = 2, use_sitemap: bool = True,
                     run_id: str | None = None, resume: bool = False) -> dict:
    start_url = normalize_url(start_url)
    if not start_url:
        raise ValueError("A valid absolute HTTP(S) URL is required.")
    if max_pages < 1 or max_depth < 0:
        raise ValueError("max_pages must be >= 1 and max_depth >= 0")

    run_id = run_id or str(uuid.uuid4())
    db_path = cfg["database_path"]
    if resume:
        run = get_run(db_path, run_id)
        if not run:
            raise ValueError(f"Unknown crawl run_id: {run_id}")
        if run["start_url"] != start_url:
            raise ValueError("Resume URL does not match the original crawl run.")
        recovered = recover_interrupted_jobs(db_path, run_id)
    else:
        if run_exists(db_path, run_id):
            raise ValueError(f"Crawl run_id already exists: {run_id}")
        recovered = 0

    # Validate before creating network requests (robots.txt, sitemap, or page fetch).
    validate_public_http_url(start_url)

    if not resume:
        create_run(db_path, run_id, start_url)
        if use_sitemap:
            sitemap_urls = await discover_sitemap_urls(
                start_url, cfg["user_agent"], cfg["timeout_seconds"], max_pages
            )
            enqueue_jobs(db_path, run_id, [
                (item, 0) for item in sitemap_urls if item != start_url
            ])

    robots_cache = {}
    raw_dir = Path(cfg["raw_dir"])
    raw_dir.mkdir(parents=True, exist_ok=True)
    saved = 0
    errors, blocked = [], []
    visited_this_call = 0
    stop_run = False

    while visited_this_call < max_pages:
        job = claim_next_job(db_path, run_id)
        if not job:
            break
        url, depth = job["url"], job["depth"]
        visited_this_call += 1

        if depth > max_depth:
            finish_job(db_path, job["id"], "blocked", "max_depth_exceeded")
            blocked.append({"url": url, "reason": "max_depth_exceeded"})
            continue

        # Sitemap-discovered URLs are untrusted; validate each before robots.txt.
        try:
            validate_public_http_url(url)
        except UnsafeURLError as exc:
            finish_job(db_path, job["id"], "blocked", str(exc))
            blocked.append({"url": url, "reason": "unsafe_destination"})
            continue

        if cfg.get("respect_robots_txt", True):
            parsed = urlparse(url)
            origin = f"{parsed.scheme}://{parsed.netloc}"
            if origin not in robots_cache:
                robots_cache[origin] = await load_robots_policy(
                    url, cfg["user_agent"], cfg["timeout_seconds"]
                )
            parser, policy_retrieved = robots_cache[origin]
            allowed = bool(policy_retrieved and parser and parser.can_fetch(cfg["user_agent"], url))
            if not allowed:
                finish_job(db_path, job["id"], "blocked", "robots_disallow_or_policy_unavailable")
                blocked.append({"url": url, "reason": "robots_disallow_or_policy_unavailable"})
                continue

        delay = float(cfg.get("request_delay_seconds", 2))
        if delay:
            await asyncio.sleep(delay)

        try:
            html, final_url, status = await fetch_http(url, cfg)
            if not same_origin(final_url, start_url):
                raise RuntimeError("Cross-origin redirect rejected by same-origin crawl policy.")
            extracted = extract_page(html)
            title, text = extracted["title"], extracted["text"]
            digest = sha256_text(html)
            record = ExtractedRecord(
                source_url=final_url,
                collected_at=datetime.now(timezone.utc).isoformat(),
                title=title, text=text, content_hash=digest,
                status="valid" if title or text else "empty",
                metadata={
                    "http_status": status, "crawl_depth": depth, "mode": "http",
                    "crawl_run_id": run_id,
                    "page_metadata": extracted["metadata"],
                    "jsonld": extracted["jsonld"],
                    "structured_entities": extracted.get("structured_entities", []),
                    "quality_score": quality_score(
                        100 if title and text else 50 if text else 0,
                        100 if status == 200 else 0, 70, 100, 100,
                    ),
                },
            )
            record = normalize_record(record)
            raw_path = raw_dir / f"{digest}.html"
            if not raw_path.exists():
                raw_path.write_text(html, encoding="utf-8")
            inserted = save_record(db_path, record)
            if inserted:
                saved += 1
            append_event(
                db_path, final_url, "page_collected",
                {"content_hash": digest, "http_status": status,
                 "crawl_run_id": run_id, "crawl_depth": depth,
                 "record_inserted": inserted, "raw_archive": str(raw_path)},
            )
            save_snapshot(
                db_path, final_url, digest, title, text, record.collected_at
            )
            if depth < max_depth:
                discovered = [
                    (link, depth + 1)
                    for link in extract_links(html, final_url, start_url)
                ]
                enqueue_jobs(db_path, run_id, discovered)
            finish_job(db_path, job["id"], "done")
        except Exception as exc:
            message = str(exc)
            finish_job(db_path, job["id"], "error", message)
            errors.append({"url": url, "error": message[:500]})
            if "HTTP 401" in message or "HTTP 403" in message or "HTTP 429" in message:
                stop_run = True
                break

    stats = queue_stats(db_path, run_id)
    if stop_run:
        status = "paused"
    elif stats["pending"] or stats["in_progress"]:
        status = "paused"
    elif stats["error"]:
        status = "completed"
    else:
        status = "completed"
    set_run_status(db_path, run_id, status)
    return {
        "run_id": run_id,
        "run_status": status,
        "start_url": start_url,
        "visited_this_call": visited_this_call,
        "visited": visited_this_call,  # backwards-compatible result key
        "saved_new_records": saved,
        "errors": errors,
        "blocked_by_policy": blocked,
        "queue": stats,
        "recovered_interrupted_jobs": recovered,
        "max_pages_per_call": max_pages,
        "max_depth": max_depth,
    }
