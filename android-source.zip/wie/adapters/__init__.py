"""Optional crawler engine adapters."""
