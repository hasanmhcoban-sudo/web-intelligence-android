"""Optional Scrapy adapter. Install requirements-scrapy.txt to enable it."""
from datetime import datetime, timezone
from pathlib import Path
from urllib.parse import urlsplit, urljoin
import hashlib

from ..policy.url_safety import validate_public_http_url, UnsafeURLError
from ..extract.html import extract_page
from ..models import ExtractedRecord
from ..storage.db import save_record


def same_origin(base_url: str, candidate_url: str) -> bool:
    base, candidate = urlsplit(base_url), urlsplit(candidate_url)
    return (candidate.scheme in ("http", "https")
            and candidate.scheme == base.scheme
            and candidate.hostname == base.hostname
            and (candidate.port or (443 if candidate.scheme == "https" else 80))
                == (base.port or (443 if base.scheme == "https" else 80)))



class PublicTargetGuard:
    """Validate every outgoing request, including redirects, before network access."""
    def process_request(self, request, spider):
        from scrapy.exceptions import IgnoreRequest
        try:
            validate_public_http_url(request.url)
            if not same_origin(spider.start_url, request.url):
                raise UnsafeURLError("Cross-origin request rejected by crawl policy")
        except UnsafeURLError as exc:
            spider.crawler.stats.inc_value("wie/unsafe_requests_rejected")
            raise IgnoreRequest(str(exc))


class RecordPipeline:
    def process_item(self, item, spider):
        raw_html = item.pop("raw_html", "")
        record = ExtractedRecord(
            source_url=item["source_url"],
            collected_at=item["collected_at"],
            title=item["title"],
            text=item["text"],
            content_hash=item["content_hash"],
            status=item["status"],
            metadata=item["metadata"],
        )
        raw_dir = Path(spider.settings.get("WIE_RAW_DIR", "data/raw"))
        raw_dir.mkdir(parents=True, exist_ok=True)
        raw_path = raw_dir / f"{record.content_hash}.html"
        if raw_html and not raw_path.exists():
            raw_path.write_text(raw_html, encoding="utf-8")
        save_record(spider.settings["WIE_DATABASE_PATH"], record)
        return item

def _scrapy_settings(config: dict) -> dict:
    return {
        "LOG_LEVEL": "INFO",
        "ROBOTSTXT_OBEY": True,
        "ROBOTSTXT_USER_AGENT": config["user_agent"],
        "USER_AGENT": config["user_agent"],
        "AUTOTHROTTLE_ENABLED": True,
        "AUTOTHROTTLE_START_DELAY": 1.0,
        "AUTOTHROTTLE_MAX_DELAY": 15.0,
        "AUTOTHROTTLE_TARGET_CONCURRENCY": 1.0,
        "CONCURRENT_REQUESTS": 2,
        "DOWNLOAD_DELAY": max(1.0, float(config.get("request_delay_seconds", 1.0))),
        "RETRY_ENABLED": True,
        "RETRY_TIMES": 2,
        # Never retry access-control or rate-limit responses.
        "RETRY_HTTP_CODES": [500, 502, 503, 504],
        "REDIRECT_ENABLED": True,
        "DOWNLOAD_TIMEOUT": float(config.get("timeout_seconds", 20)),
        "TELNETCONSOLE_ENABLED": False,
        "DOWNLOADER_MIDDLEWARES": {
            "wie.adapters.scrapy_adapter.PublicTargetGuard": 50,
        },
        "ITEM_PIPELINES": {
            "wie.adapters.scrapy_adapter.RecordPipeline": 300,
        },
        "WIE_DATABASE_PATH": config["database_path"],
        "WIE_RAW_DIR": config["raw_dir"],
    }


def _components():
    try:
        import scrapy
        from scrapy.exceptions import IgnoreRequest
        from scrapy.crawler import CrawlerProcess
    except ImportError as exc:
        raise RuntimeError(
            "Scrapy adapter is optional. Install it with: pip install -r requirements-scrapy.txt"
        ) from exc

    class WIEScrapySpider(scrapy.Spider):
        name = "wie_public_same_origin"
        custom_settings = {
            "ROBOTSTXT_OBEY": True,
            "AUTOTHROTTLE_ENABLED": True,
            "AUTOTHROTTLE_START_DELAY": 1.0,
            "AUTOTHROTTLE_MAX_DELAY": 15.0,
            "AUTOTHROTTLE_TARGET_CONCURRENCY": 1.0,
            "CONCURRENT_REQUESTS": 2,
            "RETRY_ENABLED": True,
            "RETRY_TIMES": 2,
            "RETRY_HTTP_CODES": [500, 502, 503, 504],
            "REDIRECT_ENABLED": True,
            "DOWNLOAD_TIMEOUT": 20,
            "TELNETCONSOLE_ENABLED": False,
            "LOG_LEVEL": "INFO",
        }

        def __init__(self, start_url, config, max_pages=30, max_depth=2, *args, **kwargs):
            super().__init__(*args, **kwargs)
            self.start_url = start_url
            self.config = config
            self.max_pages = max(1, int(max_pages))
            self.max_depth_limit = max(0, int(max_depth))
            parsed = urlsplit(start_url)
            self.allowed_domains = [parsed.hostname]
            self.visited_count = 0
            self.seen_urls = set()
            self.user_agent_value = config["user_agent"]
            self.custom_settings = {
                **self.custom_settings,
                "USER_AGENT": self.user_agent_value,
                "DOWNLOAD_DELAY": max(1.0, float(config.get("request_delay_seconds", 1.0))),
                "ROBOTSTXT_USER_AGENT": self.user_agent_value,
                "DEPTH_LIMIT": self.max_depth_limit,
                "DEPTH_STATS_VERBOSE": True,
                "DOWNLOADER_MIDDLEWARES": {
                    "wie.adapters.scrapy_adapter.PublicTargetGuard": 50,
                },
                "ITEM_PIPELINES": {
                    "wie.adapters.scrapy_adapter.RecordPipeline": 300,
                },
                "WIE_DATABASE_PATH": config["database_path"],
                "WIE_RAW_DIR": config["raw_dir"],
            }

        def start_requests(self):
            yield scrapy.Request(self.start_url, callback=self.parse,
                                 errback=self.request_failed, dont_filter=False)

        def request_failed(self, failure):
            self.logger.warning("Request failed: %s", failure)

        def parse(self, response):
            if response.status in (401, 403, 429):
                self.logger.warning("Access/rate limit response; stopping this branch: %s %s",
                                    response.status, response.url)
                return
            if response.status >= 500:
                self.logger.warning("Server error; response not extracted: %s %s",
                                    response.status, response.url)
                return
            if not same_origin(self.start_url, response.url):
                self.logger.warning("Cross-origin response ignored: %s", response.url)
                return
            self.visited_count += 1
            page = extract_page(response.text)
            digest = hashlib.sha256(response.text.encode("utf-8", errors="replace")).hexdigest()
            yield {
                "source_url": response.url,
                "collected_at": datetime.now(timezone.utc).isoformat(),
                "title": page["title"],
                "text": page["text"],
                "content_hash": digest,
                "status": "valid" if page["title"] or page["text"] else "empty",
                "metadata": {
                    "http_status": response.status,
                    "mode": "scrapy",
                    "page_metadata": page["metadata"],
                    "jsonld": page["jsonld"],
                    "structured_entities": page.get("structured_entities", []),
                },
                "raw_html": response.text,
            }
            if self.visited_count >= self.max_pages:
                self.crawler.engine.close_spider(self, reason="max_pages_reached")
                return
            if response.meta.get("depth", 0) >= self.max_depth_limit:
                return
            for href in response.css("a::attr(href)").getall():
                candidate = response.urljoin(href).split("#", 1)[0]
                if candidate in self.seen_urls or not same_origin(self.start_url, candidate):
                    continue
                self.seen_urls.add(candidate)
                yield scrapy.Request(candidate, callback=self.parse,
                                     errback=self.request_failed)

    return CrawlerProcess, WIEScrapySpider


def run_scrapy_crawl(start_url: str, config: dict, max_pages: int = 30, max_depth: int = 2):
    """Run Scrapy as a standalone synchronous crawl process."""
    validate_public_http_url(start_url)
    CrawlerProcess, Spider = _components()
    process = CrawlerProcess(settings=_scrapy_settings(config))
    process.crawl(Spider, start_url=start_url, config=config,
                  max_pages=max_pages, max_depth=max_depth)
    process.start(stop_after_crawl=True)
