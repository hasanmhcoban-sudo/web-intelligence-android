from urllib.robotparser import RobotFileParser
from urllib.parse import urlsplit, urlunsplit
import httpx

async def load_robots_policy(url: str, user_agent: str, timeout: float = 10.0):
    """Return (parser, policy_retrieved_safely). Fail closed when policy is unknown."""
    parts = urlsplit(url)
    robots_url = urlunsplit((parts.scheme, parts.netloc, "/robots.txt", "", ""))
    parser = RobotFileParser()
    try:
        async with httpx.AsyncClient(timeout=timeout, follow_redirects=False,
                                     headers={"User-Agent": user_agent}) as client:
            response = await client.get(robots_url)
            if response.status_code == 404:
                parser.parse([])
                return parser, True
            if response.status_code in (301, 302, 303, 307, 308):
                # Do not follow robots redirects blindly; policy remains unknown.
                return None, False
            if response.status_code in (401, 403) or response.status_code >= 400:
                return None, False
            parser.parse(response.text.splitlines())
            return parser, True
    except httpx.HTTPError:
        return None, False

async def allowed_by_robots(url: str, user_agent: str, timeout: float = 10.0) -> bool:
    parser, retrieved = await load_robots_policy(url, user_agent, timeout)
    return bool(retrieved and parser and parser.can_fetch(user_agent, url))
