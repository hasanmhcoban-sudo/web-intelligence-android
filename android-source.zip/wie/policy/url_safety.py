import ipaddress
import socket
from urllib.parse import urlsplit

class UnsafeURLError(ValueError):
    pass

def validate_public_http_url(url: str, resolver=socket.getaddrinfo) -> str:
    """Validate URL syntax and reject hostnames resolving to non-public IP addresses.

    This is a defense-in-depth check, not a substitute for outbound network firewalling:
    DNS can change between validation and connection (DNS rebinding).
    """
    try:
        parsed = urlsplit(url)
        if parsed.scheme not in ("http", "https"):
            raise UnsafeURLError("Only HTTP and HTTPS URLs are allowed.")
        if not parsed.hostname or parsed.username is not None or parsed.password is not None:
            raise UnsafeURLError("URL must have a hostname and must not contain credentials.")
        if parsed.port is not None and not (1 <= parsed.port <= 65535):
            raise UnsafeURLError("Invalid port.")
        host = parsed.hostname.rstrip(".").lower()
        if host in {"localhost", "localhost.localdomain"} or host.endswith(".localhost"):
            raise UnsafeURLError("Localhost destinations are not allowed.")

        try:
            addresses = [ipaddress.ip_address(host)]
        except ValueError:
            try:
                results = resolver(host, parsed.port or (443 if parsed.scheme == "https" else 80),
                                   type=socket.SOCK_STREAM)
            except OSError as exc:
                raise UnsafeURLError(f"DNS resolution failed: {exc}") from exc
            addresses = []
            for result in results:
                sockaddr = result[4]
                addresses.append(ipaddress.ip_address(sockaddr[0].split("%")[0]))

        if not addresses:
            raise UnsafeURLError("Hostname did not resolve to an address.")
        for address in addresses:
            if (address.is_private or address.is_loopback or address.is_link_local
                    or address.is_multicast or address.is_reserved or address.is_unspecified):
                raise UnsafeURLError(f"Non-public destination rejected: {address}")
        return url
    except ValueError as exc:
        if isinstance(exc, UnsafeURLError):
            raise
        raise UnsafeURLError(f"Invalid URL: {exc}") from exc
