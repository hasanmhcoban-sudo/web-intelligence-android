"""Local SQLite collection profiling and data-quality diagnostics."""
from collections import Counter
from urllib.parse import urlsplit
import json
from ..storage.db import connect

def profile_database(path: str) -> dict:
    con = connect(path)
    try:
        rows = con.execute(
            "SELECT source_url,title,text,content_hash,status,metadata_json FROM records"
        ).fetchall()
        total = len(rows)
        statuses = Counter()
        domains = Counter()
        metadata_keys = Counter()
        missing_title = 0
        empty_text = 0
        hashes = Counter()
        text_lengths = []
        for row in rows:
            statuses[row[4]] += 1
            host = urlsplit(row[0]).hostname or "(invalid)"
            domains[host.lower()] += 1
            missing_title += not bool((row[1] or "").strip())
            empty_text += not bool((row[2] or "").strip())
            hashes[row[3]] += 1
            text_lengths.append(len(row[2] or ""))
            try:
                metadata = json.loads(row[5] or "{}")
                if isinstance(metadata, dict):
                    metadata_keys.update(metadata.keys())
            except (TypeError, json.JSONDecodeError):
                metadata_keys["__invalid_metadata_json__"] += 1
        duplicate_groups = sum(1 for n in hashes.values() if n > 1)
        duplicate_excess = sum(n - 1 for n in hashes.values() if n > 1)
        sorted_lengths = sorted(text_lengths)
        median = (
            sorted_lengths[len(sorted_lengths)//2] if total and total % 2
            else (sorted_lengths[total//2-1] + sorted_lengths[total//2]) / 2
            if total else 0
        )
        snapshots = con.execute(
            "SELECT COUNT(*) FROM page_snapshots"
        ).fetchone()[0] if con.execute(
            "SELECT 1 FROM sqlite_master WHERE type='table' AND name='page_snapshots'"
        ).fetchone() else 0
        evidence = con.execute(
            "SELECT COUNT(*) FROM evidence_events"
        ).fetchone()[0] if con.execute(
            "SELECT 1 FROM sqlite_master WHERE type='table' AND name='evidence_events'"
        ).fetchone() else 0
        return {
            "record_count": total,
            "status_counts": dict(statuses),
            "unique_domains": len(domains),
            "top_domains": domains.most_common(20),
            "missing_title_count": missing_title,
            "empty_text_count": empty_text,
            "duplicate_hash_groups": duplicate_groups,
            "duplicate_excess_records": duplicate_excess,
            "text_length": {
                "min": min(text_lengths) if total else 0,
                "median": median,
                "max": max(text_lengths) if total else 0,
                "mean": round(sum(text_lengths)/total, 2) if total else 0,
            },
            "common_metadata_keys": metadata_keys.most_common(30),
            "snapshot_count": snapshots,
            "evidence_event_count": evidence,
        }
    finally:
        con.close()
