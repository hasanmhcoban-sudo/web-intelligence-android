"""Tamper-evident append-only collection event chain stored in SQLite."""
from datetime import datetime, timezone
import hashlib
import json
import sqlite3

GENESIS = "0" * 64

def _connect(path):
    con = sqlite3.connect(path, timeout=30)
    con.row_factory = sqlite3.Row
    con.execute("PRAGMA busy_timeout=30000")
    return con

def _canonical(payload):
    return json.dumps(payload, sort_keys=True, ensure_ascii=False,
                      separators=(",", ":"), default=str)

def _event_hash(previous_hash, payload):
    material = previous_hash + "\n" + _canonical(payload)
    return hashlib.sha256(material.encode("utf-8")).hexdigest()

def initialize_chain(path):
    con = _connect(path)
    try:
        con.execute("""
        CREATE TABLE IF NOT EXISTS evidence_events (
            id INTEGER PRIMARY KEY,
            event_time TEXT NOT NULL,
            source_url TEXT NOT NULL,
            event_type TEXT NOT NULL,
            payload_json TEXT NOT NULL,
            previous_hash TEXT NOT NULL,
            event_hash TEXT NOT NULL UNIQUE
        )
        """)
        con.commit()
    finally:
        con.close()

def append_event(path, source_url, event_type, payload):
    if not isinstance(payload, dict):
        raise ValueError("Evidence payload must be a mapping")
    initialize_chain(path)
    con = _connect(path)
    try:
        con.execute("BEGIN IMMEDIATE")
        last = con.execute(
            "SELECT event_hash FROM evidence_events ORDER BY id DESC LIMIT 1"
        ).fetchone()
        previous = last["event_hash"] if last else GENESIS
        event_time = datetime.now(timezone.utc).isoformat()
        envelope = {
            "event_time": event_time,
            "source_url": source_url,
            "event_type": event_type,
            "payload": payload,
        }
        digest = _event_hash(previous, envelope)
        con.execute(
            """INSERT INTO evidence_events
               (event_time,source_url,event_type,payload_json,previous_hash,event_hash)
               VALUES(?,?,?,?,?,?)""",
            (event_time, source_url, event_type, _canonical(payload), previous, digest),
        )
        con.commit()
        return {"event_hash": digest, "previous_hash": previous, "event_time": event_time}
    finally:
        con.close()

def verify_chain(path):
    initialize_chain(path)
    con = _connect(path)
    try:
        rows = con.execute("SELECT * FROM evidence_events ORDER BY id").fetchall()
        previous = GENESIS
        for row in rows:
            payload = json.loads(row["payload_json"])
            envelope = {
                "event_time": row["event_time"],
                "source_url": row["source_url"],
                "event_type": row["event_type"],
                "payload": payload,
            }
            expected = _event_hash(previous, envelope)
            if row["previous_hash"] != previous or row["event_hash"] != expected:
                return {
                    "valid": False,
                    "verified_events": 0 if row["id"] == 1 else row["id"] - 1,
                    "failed_event_id": row["id"],
                    "event_count": len(rows),
                }
            previous = row["event_hash"]
        return {
            "valid": True,
            "verified_events": len(rows),
            "failed_event_id": None,
            "event_count": len(rows),
            "head_hash": previous,
        }
    finally:
        con.close()
