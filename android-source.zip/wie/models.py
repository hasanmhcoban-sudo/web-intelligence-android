from dataclasses import dataclass, asdict
from typing import Any
import json

@dataclass
class ExtractedRecord:
    source_url: str
    collected_at: str
    title: str
    text: str
    content_hash: str
    status: str = "valid"
    metadata: dict[str, Any] | None = None

    def to_json(self):
        return json.dumps(asdict(self), ensure_ascii=False)
