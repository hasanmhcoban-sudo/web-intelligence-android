"""Optional OCR for image-only PDFs; requires pypdfium2 and system Tesseract."""
from shutil import which

def ocr_pdf(path: str, languages: str = "eng", max_pages: int = 20,
            scale: float = 2.0) -> dict:
    if max_pages < 1 or max_pages > 100:
        raise ValueError("max_pages must be between 1 and 100")
    if scale < 1.0 or scale > 4.0:
        raise ValueError("scale must be between 1.0 and 4.0")
    if not which("tesseract"):
        raise RuntimeError(
            "OCR requires the free Tesseract system binary. Install Tesseract and language packs first."
        )
    try:
        import pypdfium2 as pdfium
        import pytesseract
    except ImportError as exc:
        raise RuntimeError(
            "OCR Python extras missing. Install with: pip install -r requirements-ocr.txt"
        ) from exc

    pdf = pdfium.PdfDocument(path)
    pages = []
    try:
        count = min(len(pdf), max_pages)
        for index in range(count):
            page = pdf[index]
            bitmap = page.render(scale=scale)
            image = bitmap.to_pil()
            text = pytesseract.image_to_string(image, lang=languages)
            pages.append({"page": index + 1, "text": text.strip()})
            page.close()
        return {
            "pages": pages,
            "pages_processed": count,
            "pages_total": len(pdf),
            "truncated": len(pdf) > count,
            "languages": languages,
        }
    finally:
        pdf.close()
