"""Extract and normalize public Schema.org entities from HTML.

Supports JSON-LD, Microdata and a conservative RDFa subset. It does not
execute scripts or fetch linked resources.
"""
import json
from bs4 import BeautifulSoup

SUPPORTED_TYPES = {
    "Article", "NewsArticle", "BlogPosting", "Product", "Offer", "Organization",
    "LocalBusiness", "WebSite", "WebPage", "Event", "Course", "Book",
    "SoftwareApplication", "Recipe", "BreadcrumbList", "Person",
}

def _local_name(value):
    value = str(value).rsplit("/", 1)[-1].rsplit("#", 1)[-1]
    return value.rsplit(":", 1)[-1]

def _type_name(value):
    if isinstance(value, str):
        return _local_name(value)
    if isinstance(value, list):
        return [_type_name(v) for v in value]
    return value

def _flatten_jsonld(value):
    if isinstance(value, list):
        for item in value:
            yield from _flatten_jsonld(item)
    elif isinstance(value, dict):
        graph = value.get("@graph")
        if isinstance(graph, list):
            for item in graph:
                yield from _flatten_jsonld(item)
        if value.get("@type") or value.get("itemtype"):
            yield value

def _clean_entity(entity, source):
    kind = _type_name(entity.get("@type") or entity.get("itemtype"))
    if isinstance(kind, list):
        kind = [x for x in kind if isinstance(x, str)]
    normalized = {}
    for key in ("name", "headline", "description", "url", "datePublished",
                "dateModified", "image", "author", "publisher", "brand",
                "sku", "price", "priceCurrency", "availability", "startDate",
                "endDate", "address", "itemListElement", "sameAs"):
        if key in entity:
            normalized[key] = entity[key]
    return {
        "type": kind,
        "name": normalized.get("name") or normalized.get("headline"),
        "properties": normalized,
        "source_format": source,
    }

def extract_jsonld_entities(html: str) -> list[dict]:
    soup = BeautifulSoup(html, "html.parser")
    results = []
    for script in soup.find_all("script", attrs={"type": "application/ld+json"}):
        raw = script.string or script.get_text()
        try:
            parsed = json.loads(raw)
        except (json.JSONDecodeError, TypeError):
            continue
        for entity in _flatten_jsonld(parsed):
            results.append(_clean_entity(entity, "json-ld"))
    return results[:100]

def _microdata_value(node):
    if node.has_attr("content"):
        return node.get("content")
    if node.name in {"meta"}:
        return node.get("content")
    if node.name in {"a", "link"}:
        return node.get("href")
    if node.name in {"img", "audio", "embed", "iframe", "source", "video"}:
        return node.get("src") or node.get("data")
    if node.name in {"time", "data", "meter"}:
        return node.get("datetime") or node.get("value") or node.get_text(" ", strip=True)
    nested = node.find(attrs={"itemscope": True})
    if nested and nested is not node:
        return {"itemtype": nested.get("itemtype"), "name": nested.get_text(" ", strip=True)[:500]}
    return node.get_text(" ", strip=True)[:2000]

def extract_microdata_entities(html: str) -> list[dict]:
    soup = BeautifulSoup(html, "html.parser")
    entities = []
    for scope in soup.find_all(attrs={"itemscope": True}):
        # Nested scopes are represented as their own entity, not duplicated as parent props.
        if scope.find_parent(attrs={"itemscope": True}):
            continue
        props = {}
        for node in scope.find_all(attrs={"itemprop": True}):
            if node.find_parent(attrs={"itemscope": True}) is not scope:
                continue
            for prop in str(node.get("itemprop", "")).split():
                value = _microdata_value(node)
                props[prop] = value
        kind = _type_name(scope.get("itemtype", ""))
        entities.append({
            "type": kind,
            "name": props.get("name") or props.get("headline"),
            "properties": props,
            "source_format": "microdata",
        })
    return entities[:100]

def extract_rdfa_entities(html: str) -> list[dict]:
    soup = BeautifulSoup(html, "html.parser")
    entities = []
    for scope in soup.find_all(attrs={"typeof": True}):
        if scope.find_parent(attrs={"typeof": True}):
            continue
        props = {}
        for node in scope.find_all(attrs={"property": True}):
            if node.find_parent(attrs={"typeof": True}) is not scope:
                continue
            value = node.get("content") or node.get("href") or node.get("src") or node.get_text(" ", strip=True)
            for prop in str(node.get("property", "")).split():
                props[_local_name(prop)] = value[:2000] if isinstance(value, str) else value
        entities.append({
            "type": _type_name(scope.get("typeof", "").split()),
            "name": props.get("name") or props.get("headline"),
            "properties": props,
            "source_format": "rdfa",
        })
    return entities[:100]

def extract_structured_entities(html: str) -> list[dict]:
    """Return normalized entities, preferring JSON-LD then other embedded formats."""
    all_entities = (
        extract_jsonld_entities(html)
        + extract_microdata_entities(html)
        + extract_rdfa_entities(html)
    )
    seen = set()
    unique = []
    for entity in all_entities:
        fingerprint = json.dumps(
            [entity.get("type"), entity.get("name"), entity.get("properties", {})],
            sort_keys=True, ensure_ascii=False, default=str,
        )
        if fingerprint not in seen:
            seen.add(fingerprint)
            unique.append(entity)
    return unique[:200]
