from pathlib import Path
import csv
import json

class DocumentExtractionError(RuntimeError):
    pass

def extract_document(path: str, *, ocr: bool = False,
                     ocr_languages: str = "eng", ocr_max_pages: int = 20) -> dict:
    """Extract text/tables from supported local document formats.

    Optional parsers are imported only for their matching file type.
    """
    file_path = Path(path)
    if not file_path.is_file():
        raise FileNotFoundError(path)
    suffix = file_path.suffix.lower()

    if suffix in {".txt", ".md", ".html", ".htm", ".json"}:
        raw = file_path.read_text(encoding="utf-8", errors="replace")
        if suffix == ".json":
            try:
                data = json.loads(raw)
                return {"format": "json", "text": json.dumps(data, ensure_ascii=False, indent=2),
                        "metadata": {"valid_json": True}}
            except json.JSONDecodeError as exc:
                raise DocumentExtractionError(f"Invalid JSON: {exc}") from exc
        if suffix in {".html", ".htm"}:
            from .html import extract_page
            result = extract_page(raw)
            return {"format": "html", "text": result["text"], "metadata": result["metadata"]}
        return {"format": suffix[1:], "text": raw, "metadata": {}}

    if suffix == ".csv":
        with file_path.open("r", encoding="utf-8-sig", newline="") as handle:
            rows = list(csv.reader(handle))
        return {"format": "csv", "text": "\n".join(" | ".join(row) for row in rows),
                "metadata": {"row_count": len(rows)}}

    if suffix == ".pdf":
        try:
            from pypdf import PdfReader
        except ImportError as exc:
            raise DocumentExtractionError("PDF support requires pypdf (free/open source).") from exc
        try:
            reader = PdfReader(str(file_path))
            pages = [page.extract_text() or "" for page in reader.pages]
            text = "\n\n".join(pages)
            metadata = {
                "page_count": len(reader.pages),
                "encrypted": reader.is_encrypted,
                "ocr_used": False,
            }
            if ocr and not text.strip() and not reader.is_encrypted:
                from .ocr import ocr_pdf
                ocr_result = ocr_pdf(
                    str(file_path), languages=ocr_languages, max_pages=ocr_max_pages
                )
                text = "\n\n".join(
                    f"[Page {item['page']}]\n{item['text']}"
                    for item in ocr_result["pages"]
                )
                metadata["ocr_used"] = True
                metadata["ocr_pages_processed"] = ocr_result["pages_processed"]
                metadata["ocr_truncated"] = ocr_result["truncated"]
            return {"format": "pdf", "text": text, "metadata": metadata}
        except Exception as exc:
            raise DocumentExtractionError(f"PDF extraction failed: {exc}") from exc

    if suffix == ".docx":
        try:
            from docx import Document
        except ImportError as exc:
            raise DocumentExtractionError("DOCX support requires python-docx (free/open source).") from exc
        try:
            doc = Document(str(file_path))
            paragraphs = [p.text for p in doc.paragraphs if p.text.strip()]
            tables = []
            for table in doc.tables:
                tables.append([[cell.text for cell in row.cells] for row in table.rows])
            return {"format": "docx", "text": "\n".join(paragraphs),
                    "metadata": {"paragraph_count": len(paragraphs), "tables": tables}}
        except Exception as exc:
            raise DocumentExtractionError(f"DOCX extraction failed: {exc}") from exc

    if suffix == ".xlsx":
        try:
            from openpyxl import load_workbook
        except ImportError as exc:
            raise DocumentExtractionError("XLSX support requires openpyxl (free/open source).") from exc
        try:
            workbook = load_workbook(filename=str(file_path), read_only=True, data_only=True)
            sheets = {}
            for sheet in workbook.worksheets:
                sheets[sheet.title] = [
                    [cell for cell in row]
                    for row in sheet.iter_rows(values_only=True)
                ]
            workbook.close()
            text = "\n".join(
                f"[{name}]\\n" + "\n".join(" | ".join("" if v is None else str(v) for v in row)
                                             for row in rows)
                for name, rows in sheets.items()
            )
            return {"format": "xlsx", "text": text, "metadata": {"sheets": list(sheets)}}
        except Exception as exc:
            raise DocumentExtractionError(f"XLSX extraction failed: {exc}") from exc

    raise DocumentExtractionError(f"Unsupported file extension: {suffix or '(none)'}")
