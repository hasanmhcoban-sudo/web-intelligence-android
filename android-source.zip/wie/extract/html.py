from bs4 import BeautifulSoup
import json

def extract_page(html: str) -> dict:
    soup = BeautifulSoup(html, "html.parser")
    for node in soup(["script", "style", "noscript", "svg"]):
        if node.name != "script" or node.get("type") != "application/ld+json":
            node.decompose()

    title = soup.title.get_text(" ", strip=True) if soup.title else ""
    main = soup.find("main") or soup.find("article") or soup.body or soup
    text = " ".join(main.get_text(" ", strip=True).split())

    metadata = {}
    for tag in soup.find_all("meta"):
        key = tag.get("property") or tag.get("name")
        value = tag.get("content")
        if key and value:
            metadata[key[:100]] = value[:2000]

    canonical = soup.find("link", rel="canonical")
    if canonical and canonical.get("href"):
        metadata["canonical_url"] = canonical["href"]

    jsonld = []
    for script in soup.find_all("script", type="application/ld+json"):
        raw = script.string or script.get_text()
        try:
            parsed = json.loads(raw)
            jsonld.append(parsed)
        except (json.JSONDecodeError, TypeError):
            continue

    from .structured import extract_structured_entities
    structured_entities = extract_structured_entities(html)

    return {
        "title": title[:1000],
        "text": text[:200_000],
        "metadata": metadata,
        "jsonld": jsonld[:20],
        "structured_entities": structured_entities,
    }

def extract_title_text(html: str) -> tuple[str, str]:
    result = extract_page(html)
    return result["title"], result["text"]
