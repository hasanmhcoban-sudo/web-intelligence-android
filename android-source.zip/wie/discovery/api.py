"""Conservative discovery of explicitly advertised API documentation/spec URLs."""
from urllib.parse import urljoin, urlsplit
import json
import yaml
import httpx
from bs4 import BeautifulSoup
from ..policy.url_safety import validate_public_http_url, UnsafeURLError

API_HINTS = ("openapi", "swagger", "api-docs", "api.json", "schema.json", "service-desc")

def discover_api_candidates(html: str, page_url: str) -> list[str]:
    soup = BeautifulSoup(html, "html.parser")
    found = set()
    for tag in soup.find_all(["a", "link", "script"]):
        href = tag.get("href") or tag.get("src")
        if not href:
            continue
        rel = " ".join(tag.get("rel", [])).lower() if tag.get("rel") else ""
        hint_text = " ".join([
            href.lower(),
            tag.get_text(" ", strip=True).lower(),
            str(tag.get("type", "")).lower(),
            rel,
        ])
        if any(hint in hint_text for hint in API_HINTS):
            absolute = urljoin(page_url, href)
            parsed = urlsplit(absolute)
            if parsed.scheme in ("http", "https") and parsed.hostname:
                found.add(absolute)
    return sorted(found)

def parse_openapi_spec(content: str) -> dict:
    """Parse JSON/YAML OpenAPI documents without making any network requests."""
    try:
        data = json.loads(content)
    except json.JSONDecodeError:
        try:
            data = yaml.safe_load(content)
        except yaml.YAMLError as exc:
            raise ValueError(f"Invalid OpenAPI JSON/YAML: {exc}") from exc
    if not isinstance(data, dict):
        raise ValueError("OpenAPI document must be a mapping/object.")
    if not (str(data.get("openapi", "")).startswith("3.")
            or str(data.get("swagger", "")) == "2.0"):
        raise ValueError("Document does not declare OpenAPI 3.x or Swagger 2.0.")
    paths = data.get("paths", {})
    if not isinstance(paths, dict):
        raise ValueError("OpenAPI paths must be an object.")
    endpoints = []
    for path, operations in paths.items():
        if not isinstance(operations, dict):
            continue
        for method, operation in operations.items():
            method = str(method).upper()
            if method in {"GET", "POST", "PUT", "PATCH", "DELETE", "OPTIONS", "HEAD"}:
                endpoints.append({
                    "method": method,
                    "path": str(path),
                    "operation_id": operation.get("operationId") if isinstance(operation, dict) else None,
                    "summary": operation.get("summary") if isinstance(operation, dict) else None,
                })
    return {
        "title": (data.get("info") or {}).get("title") if isinstance(data.get("info"), dict) else None,
        "version": (data.get("info") or {}).get("version") if isinstance(data.get("info"), dict) else None,
        "servers": data.get("servers", []),
        "endpoint_count": len(endpoints),
        "endpoints": endpoints,
    }


def _same_origin(left: str, right: str) -> bool:
    a, b = urlsplit(left), urlsplit(right)
    def port(parsed):
        return parsed.port or (443 if parsed.scheme == "https" else 80)
    return (
        a.scheme in ("http", "https")
        and a.scheme == b.scheme
        and a.hostname == b.hostname
        and port(a) == port(b)
    )


async def fetch_api_spec(
    spec_url: str,
    page_url: str,
    config: dict,
    *,
    transport=None,
) -> dict:
    """Fetch and parse an explicitly advertised, same-origin public API spec.

    This function retrieves the documentation document only. It never calls
    endpoints described inside the specification.
    """
    if not _same_origin(page_url, spec_url):
        raise ValueError("Cross-origin API specification URL rejected.")
    max_bytes = int(config.get("max_response_bytes", 2_000_000))
    max_redirects = int(config.get("max_redirects", 3))
    headers = {
        "User-Agent": config["user_agent"],
        "Accept": "application/json, application/yaml, text/yaml, text/plain;q=0.9",
    }
    current = spec_url
    redirects = 0

    async with httpx.AsyncClient(
        timeout=config.get("timeout_seconds", 20),
        follow_redirects=False,
        headers=headers,
        transport=transport,
    ) as client:
        while True:
            try:
                validate_public_http_url(current)
            except UnsafeURLError as exc:
                raise ValueError(f"Unsafe API specification destination: {exc}") from exc

            async with client.stream("GET", current) as response:
                if response.status_code in (301, 302, 303, 307, 308):
                    location = response.headers.get("location")
                    if not location:
                        raise ValueError("API spec redirect has no Location header.")
                    if redirects >= max_redirects:
                        raise ValueError("Maximum API spec redirect count exceeded.")
                    destination = str(response.url.join(location))
                    if not _same_origin(page_url, destination):
                        raise ValueError("Cross-origin API spec redirect rejected.")
                    current = destination
                    redirects += 1
                    continue

                if response.status_code in (401, 403, 429):
                    raise ValueError(
                        f"API spec access denied or rate limited: HTTP {response.status_code}."
                    )
                response.raise_for_status()

                content_type = response.headers.get("content-type", "").split(";", 1)[0].lower()
                allowed_types = {
                    "application/json", "application/openapi+json",
                    "application/yaml", "application/x-yaml",
                    "text/yaml", "text/x-yaml", "text/plain",
                    "application/octet-stream",
                }
                if content_type and content_type not in allowed_types:
                    raise ValueError(f"Unsupported API spec content type: {content_type}")

                chunks, size = [], 0
                async for chunk in response.aiter_bytes():
                    size += len(chunk)
                    if size > max_bytes:
                        raise ValueError("API specification exceeded max_response_bytes.")
                    chunks.append(chunk)
                content = b"".join(chunks).decode("utf-8-sig", errors="strict")
                parsed = parse_openapi_spec(content)
                parsed["source_url"] = str(response.url)
                parsed["content_type"] = content_type or None
                parsed["bytes"] = size
                return parsed
