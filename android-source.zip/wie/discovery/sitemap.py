from urllib.parse import urlparse, urljoin
import httpx
import xml.etree.ElementTree as ET
from ..policy.url_safety import validate_public_http_url, UnsafeURLError

def parse_sitemap_xml(content: bytes) -> tuple[str, list[str]]:
    """Return ('urlset'|'index'|'unknown', loc values)."""
    root = ET.fromstring(content)
    kind = root.tag.rsplit("}", 1)[-1].lower()
    locs = [
        (elem.text or "").strip()
        for elem in root.iter()
        if elem.tag.rsplit("}", 1)[-1].lower() == "loc" and (elem.text or "").strip()
    ]
    return kind, locs

async def discover_sitemap_urls(base_url: str, user_agent: str, timeout: float = 15.0,
                                max_urls: int = 500, max_sitemaps: int = 20) -> list[str]:
    parsed = urlparse(base_url)
    origin = f"{parsed.scheme}://{parsed.netloc}"
    pending = [f"{origin}/sitemap.xml", f"{origin}/sitemap_index.xml"]
    visited_sitemaps, found = set(), []
    headers = {"User-Agent": user_agent}

    async with httpx.AsyncClient(timeout=timeout, follow_redirects=False, headers=headers) as client:
        while pending and len(visited_sitemaps) < max_sitemaps and len(found) < max_urls:
            sitemap_url = pending.pop(0)
            if sitemap_url in visited_sitemaps:
                continue
            visited_sitemaps.add(sitemap_url)
            try:
                # Do not follow sitemap redirects: destinations are untrusted.
                validate_public_http_url(sitemap_url)
                response = await client.get(sitemap_url)
                if response.status_code in (401, 403, 429) or response.status_code != 200:
                    continue
                kind, locs = parse_sitemap_xml(response.content)
                for loc in locs:
                    absolute = urljoin(sitemap_url, loc)
                    target = urlparse(absolute)
                    if (target.scheme.lower(), target.netloc.lower()) != (
                        parsed.scheme.lower(), parsed.netloc.lower()
                    ):
                        continue
                    if kind == "sitemapindex":
                        if absolute not in visited_sitemaps:
                            pending.append(absolute)
                    elif kind == "urlset":
                        found.append(absolute)
                        if len(found) >= max_urls:
                            break
            except (httpx.HTTPError, ET.ParseError, UnsafeURLError):
                continue
    return list(dict.fromkeys(found))[:max_urls]
