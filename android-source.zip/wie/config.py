from pathlib import Path
import yaml

DEFAULTS = {
    "user_agent": "WebIntelligenceEngine/1.0",
    "timeout_seconds": 20,
    "max_retries": 2,
    "max_redirects": 5,
    "request_delay_seconds": 2.0,
    "respect_robots_txt": True,
    "max_response_bytes": 5_000_000,
    "database_path": "data/records.sqlite3",
    "raw_dir": "data/raw",
    "export_dir": "data/exports",
}

def load_config(path="config/settings.yaml"):
    cfg = DEFAULTS.copy()
    p = Path(path)
    if p.exists():
        loaded = yaml.safe_load(p.read_text(encoding="utf-8")) or {}
        if not isinstance(loaded, dict):
            raise ValueError("Config must be a YAML mapping")
        cfg.update(loaded)
    for key in ("timeout_seconds", "max_retries", "request_delay_seconds", "max_response_bytes"):
        if cfg[key] < 0:
            raise ValueError(f"{key} must be non-negative")
    return cfg
