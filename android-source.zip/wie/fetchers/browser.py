from ..policy.url_safety import validate_public_http_url, UnsafeURLError

def validate_browser_request_url(url: str) -> None:
    """Reject unsafe destinations for top-level and subresource browser requests."""
    try:
        validate_public_http_url(url)
    except UnsafeURLError as exc:
        raise RuntimeError(f"Browser request blocked by URL safety policy: {exc}") from exc

async def fetch_browser(url: str, cfg: dict) -> tuple[str, str, int]:
    try:
        from playwright.async_api import async_playwright
    except ImportError as exc:
        raise RuntimeError(
            "Browser mode requires optional dependency: pip install playwright && playwright install chromium"
        ) from exc

    validate_browser_request_url(url)
    async with async_playwright() as p:
        browser = await p.chromium.launch(headless=True)
        try:
            context = await browser.new_context(
                user_agent=cfg["user_agent"],
                accept_downloads=False,
                service_workers="block",
            )
            page = await context.new_page()
            blocked = []

            async def guard_route(route):
                request_url = route.request.url
                try:
                    validate_browser_request_url(request_url)
                except RuntimeError as exc:
                    blocked.append((request_url, str(exc)))
                    await route.abort("blockedbyclient")
                    return
                await route.continue_()

            await page.route("**/*", guard_route)
            response = await page.goto(
                url, wait_until="domcontentloaded",
                timeout=cfg["timeout_seconds"] * 1000,
            )
            status = response.status if response else 0
            if status in (401, 403, 429):
                raise RuntimeError(
                    f"Access denied or rate limited: HTTP {status}; no bypass attempted."
                )
            if status >= 400:
                raise RuntimeError(f"HTTP {status}")
            final_url = page.url
            validate_browser_request_url(final_url)
            html = await page.content()
            size = len(html.encode("utf-8", errors="replace"))
            if size > int(cfg["max_response_bytes"]):
                raise RuntimeError("Rendered HTML exceeded max_response_bytes")
            if blocked:
                # Record the security event in the exception only when main navigation was blocked;
                # blocked third-party resources do not invalidate an otherwise safe page.
                pass
            return html, final_url, status
        finally:
            await context.close()
            await browser.close()
