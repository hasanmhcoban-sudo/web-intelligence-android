import asyncio
import httpx
from ..policy.url_safety import validate_public_http_url, UnsafeURLError

class FetchError(RuntimeError):
    pass

async def fetch_http(url: str, cfg: dict) -> tuple[str, str, int]:
    headers = {
        "User-Agent": cfg["user_agent"],
        "Accept": "text/html,application/xhtml+xml,application/json",
    }
    timeout = cfg["timeout_seconds"]
    max_bytes = cfg["max_response_bytes"]
    max_redirects = int(cfg.get("max_redirects", 5))
    max_retries = int(cfg.get("max_retries", 2))
    current_url = url
    redirect_count = 0

    async with httpx.AsyncClient(timeout=timeout, follow_redirects=False,
                                 headers=headers) as client:
        while True:
            # Validate each destination immediately before attempting its request.
            try:
                validate_public_http_url(current_url)
            except UnsafeURLError as exc:
                raise FetchError(f"Unsafe destination rejected: {exc}") from exc

            response_html = None
            last_error = None
            for attempt in range(max_retries + 1):
                try:
                    async with client.stream("GET", current_url) as response:
                        if response.status_code in (301, 302, 303, 307, 308):
                            location = response.headers.get("location")
                            if not location:
                                raise FetchError(
                                    f"HTTP {response.status_code} without Location header"
                                )
                            if redirect_count >= max_redirects:
                                raise FetchError("Maximum redirect count exceeded.")
                            current_url = str(response.url.join(location))
                            redirect_count += 1
                            response_html = "REDIRECT"
                            break

                        if response.status_code in (401, 403, 429):
                            raise FetchError(
                                f"Access denied or rate limited: HTTP {response.status_code}; "
                                "stopping without bypass."
                            )
                        if response.status_code >= 500 and attempt < max_retries:
                            last_error = FetchError(f"Temporary server error: HTTP {response.status_code}")
                            await asyncio.sleep(min(2 ** attempt, 8))
                            continue
                        response.raise_for_status()

                        chunks, size = [], 0
                        async for chunk in response.aiter_text():
                            size += len(chunk.encode("utf-8", errors="replace"))
                            if size > max_bytes:
                                raise FetchError("Response exceeded max_response_bytes")
                            chunks.append(chunk)
                        return "".join(chunks), str(response.url), response.status_code

                except (FetchError, UnsafeURLError):
                    raise
                except (httpx.TimeoutException, httpx.NetworkError, httpx.HTTPStatusError) as exc:
                    last_error = exc
                    if isinstance(exc, httpx.HTTPStatusError) and exc.response.status_code < 500:
                        break
                    if attempt < max_retries:
                        await asyncio.sleep(min(2 ** attempt, 8))

            if response_html == "REDIRECT":
                continue
            raise FetchError(f"Fetch failed after {max_retries + 1} attempt(s): {last_error}")
