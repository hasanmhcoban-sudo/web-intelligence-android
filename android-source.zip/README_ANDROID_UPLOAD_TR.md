# Samsung telefondan APK üretimi — kısa yükleme kılavuzu

## Mevcut durum
- Python testleri: 86 başarılı, 2 atlandı.
- Android APK henüz derlenmedi ve gerçek cihazda henüz test edilmedi.
- GitHub deposu `hasanmhcoban-sudo/web-intelligence-android` içine kaynak ZIP'i yüklemek ve workflow dosyasını oluşturmak gerekiyor.

## Yükleme
1. GitHub deposunu aç: https://github.com/hasanmhcoban-sudo/web-intelligence-android
2. **Add file → Upload files** seç.
3. Bu paketten `android-source.zip` dosyasını seçip yükle ve **Commit changes** ile kaydet.
4. **Add file → Create new file** seç.
5. Dosya adını `.github/workflows/build-apk.yml` yaz.
6. Bu pakette ayrıca verilen `build-apk.yml` dosyasının içeriğini yapıştır ve commit et.
7. İkinci commit'ten sonra **Actions** sekmesinde otomatik başlayan `Build Web Intelligence APK` iş akışını aç.
8. Test ve derleme başarılı olursa sayfanın altındaki **Artifacts** bölümünden `web-intelligence-android-debug-apk` dosyasını indir.
9. ZIP arşivini aç, APK'ya dokun ve Android kurulumunu tamamla.

## Notlar
- İş akışı önce testleri çalıştırır; testler başarısız olursa APK derlemesine geçmez.
- İlk Android derlemesi Android SDK/NDK indireceği için uzun sürebilir.
- GitHub entegrasyon bağlantısı şu anda bu depoya yazma izni vermediği için dosyaları doğrudan benim yüklemem mümkün olmadı. Bu iki dosyalık yükleme işlemi depoda senin hesabınla yapılır.
- Kaynak kodda erişim kontrolü, giriş, CAPTCHA, robots.txt veya 401/403/429 kısıtlarını aşmaya yönelik özellik yoktur.
