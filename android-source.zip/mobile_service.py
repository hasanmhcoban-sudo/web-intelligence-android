"""Mobile-facing service layer for the Web Intelligence Android app."""
from __future__ import annotations

import asyncio
import sqlite3
from pathlib import Path
from urllib.parse import urlsplit

from wie.crawl import crawl_site
from wie.storage.export import export_csv, export_jsonl


def normalize_input_url(value: str) -> str:
    value = (value or "").strip()
    if not value:
        raise ValueError("Bir web sitesi adresi girin.")
    if "://" not in value:
        value = "https://" + value
    parsed = urlsplit(value)
    if parsed.scheme not in {"http", "https"} or not parsed.hostname:
        raise ValueError("Geçerli bir HTTP veya HTTPS adresi girin.")
    if parsed.username is not None or parsed.password is not None:
        raise ValueError("Kullanıcı adı/parola içeren URL'ler kabul edilmez.")
    return value


def app_config(data_dir: str | Path) -> dict:
    root = Path(data_dir)
    raw_dir = root / "raw"
    export_dir = root / "exports"
    raw_dir.mkdir(parents=True, exist_ok=True)
    export_dir.mkdir(parents=True, exist_ok=True)
    return {
        "user_agent": "WebIntelligenceAndroid/1.0 (+robots-txt-compliant)",
        "timeout_seconds": 20,
        "max_retries": 2,
        "max_redirects": 5,
        "request_delay_seconds": 1.5,
        "respect_robots_txt": True,
        "max_response_bytes": 4_000_000,
        "database_path": str(root / "records.sqlite3"),
        "raw_dir": str(raw_dir),
        "export_dir": str(export_dir),
    }


def run_mobile_crawl(url: str, max_pages: int, max_depth: int, data_dir: str | Path) -> dict:
    """Run a bounded crawl and persist it inside app-private storage."""
    normalized_url = normalize_input_url(url)
    max_pages = max(1, min(int(max_pages), 30))
    max_depth = max(0, min(int(max_depth), 2))
    cfg = app_config(data_dir)
    return asyncio.run(crawl_site(
        normalized_url,
        cfg,
        max_pages=max_pages,
        max_depth=max_depth,
        use_sitemap=False,
    ))


def recent_records(data_dir: str | Path, limit: int = 8) -> list[dict]:
    db_path = Path(data_dir) / "records.sqlite3"
    if not db_path.exists():
        return []
    con = sqlite3.connect(db_path)
    con.row_factory = sqlite3.Row
    try:
        rows = con.execute(
            "SELECT source_url,collected_at,title,status FROM records ORDER BY id DESC LIMIT ?",
            (max(1, min(int(limit), 30)),),
        ).fetchall()
        return [dict(row) for row in rows]
    finally:
        con.close()


def create_export(data_dir: str | Path, fmt: str) -> Path:
    root = Path(data_dir)
    db_path = root / "records.sqlite3"
    if not db_path.exists():
        raise ValueError("Dışa aktarılacak kayıt bulunamadı.")
    export_dir = root / "exports"
    export_dir.mkdir(parents=True, exist_ok=True)
    if fmt == "csv":
        out = export_dir / "web_intelligence_records.csv"
        export_csv(str(db_path), str(out))
    elif fmt == "jsonl":
        out = export_dir / "web_intelligence_records.jsonl"
        export_jsonl(str(db_path), str(out))
    else:
        raise ValueError("Desteklenmeyen dışa aktarma biçimi.")
    return out
