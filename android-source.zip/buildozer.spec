[app]
title = Web Intelligence
package.name = webintelligence
package.domain = org.webintelligence
source.dir = .
icon.filename = %(source.dir)s/icon.png
source.include_exts = py,png,jpg,kv,atlas,yaml,md,txt
source.exclude_dirs = tests,.git,.pytest_cache,__pycache__,.venv,bin,.buildozer
version = 1.0.0
requirements = python3,kivy==2.3.1,httpx,beautifulsoup4,certifi,idna,httpcore,anyio,sniffio,h11,typing_extensions
orientation = portrait
fullscreen = 0
android.permissions = INTERNET,ACCESS_NETWORK_STATE
android.api = 36
android.minapi = 29
android.ndk = 28c
android.archs = arm64-v8a
android.accept_sdk_license = True
android.wakelock = True
android.allow_backup = True
android.debug_artifact = apk
android.release_artifact = apk
p4a.bootstrap = sdl2
p4a.branch = master

[buildozer]
log_level = 2
warn_on_root = 1
