from wie.extract.html import extract_page

def test_extracts_meta_canonical_and_jsonld():
    html = """
    <html><head>
      <title>Sample</title>
      <meta property="og:title" content="Open Graph Title"/>
      <link rel="canonical" href="https://example.org/canonical"/>
      <script type="application/ld+json">{"@type":"Article","headline":"A headline"}</script>
    </head><body><main><p>Body text</p></main></body></html>
    """
    result = extract_page(html)
    assert result["title"] == "Sample"
    assert result["metadata"]["og:title"] == "Open Graph Title"
    assert result["metadata"]["canonical_url"] == "https://example.org/canonical"
    assert result["jsonld"][0]["headline"] == "A headline"
    assert "Body text" in result["text"]
