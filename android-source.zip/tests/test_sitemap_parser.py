from wie.discovery.sitemap import parse_sitemap_xml

def test_parse_urlset():
    xml = b'<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9"><url><loc>https://example.org/a</loc></url></urlset>'
    kind, locs = parse_sitemap_xml(xml)
    assert kind == "urlset"
    assert locs == ["https://example.org/a"]

def test_parse_sitemap_index():
    xml = b'<sitemapindex xmlns="http://www.sitemaps.org/schemas/sitemap/0.9"><sitemap><loc>https://example.org/child.xml</loc></sitemap></sitemapindex>'
    kind, locs = parse_sitemap_xml(xml)
    assert kind == "sitemapindex"
    assert locs == ["https://example.org/child.xml"]


def test_sitemap_index_rejects_other_origin():
    from wie.discovery.sitemap import parse_sitemap_xml
    xml = b'<sitemapindex><sitemap><loc>https://evil.example/map.xml</loc></sitemap></sitemapindex>'
    kind, locs = parse_sitemap_xml(xml)
    assert kind == "sitemapindex"
    assert locs == ["https://evil.example/map.xml"]
