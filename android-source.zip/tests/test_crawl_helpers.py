from wie.crawl import normalize_url, same_origin, extract_links

def test_normalize_removes_fragment():
    assert normalize_url("https://example.org/a#section") == "https://example.org/a"

def test_same_origin():
    assert same_origin("https://example.org/a", "https://example.org/b")
    assert not same_origin("https://example.org/a", "https://other.org/")

def test_extract_links_stays_on_origin():
    html = '<a href="/about">About</a><a href="https://other.org/x">Other</a><a href="#x">Anchor</a>'
    links = extract_links(html, "https://example.org/", "https://example.org/")
    assert "https://example.org/about" in links
    assert all("other.org" not in x for x in links)
