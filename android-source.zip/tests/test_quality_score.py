import pytest
from wie.quality.scoring import quality_score

def test_quality_score_weighting():
    assert quality_score(100, 100, 100, 100, 100) == 100

def test_quality_score_rejects_out_of_range():
    with pytest.raises(ValueError):
        quality_score(101, 100, 100, 100, 100)
