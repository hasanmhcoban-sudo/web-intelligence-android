import pytest
from wie.fetchers.browser import validate_browser_request_url

def test_browser_allows_public_http_url(monkeypatch):
    monkeypatch.setattr("wie.fetchers.browser.validate_public_http_url", lambda url: url)
    assert validate_browser_request_url("https://example.org") is None

def test_browser_rejects_unsafe_url(monkeypatch):
    from wie.policy.url_safety import UnsafeURLError
    def reject(url):
        raise UnsafeURLError("private address")
    monkeypatch.setattr("wie.fetchers.browser.validate_public_http_url", reject)
    with pytest.raises(RuntimeError, match="blocked by URL safety"):
        validate_browser_request_url("http://127.0.0.1")
