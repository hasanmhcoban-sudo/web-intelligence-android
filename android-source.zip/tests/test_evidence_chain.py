import sqlite3
from wie.evidence.chain import append_event, verify_chain

def test_evidence_chain_appends_and_verifies(tmp_path):
    db = str(tmp_path / "evidence.sqlite")
    first = append_event(db, "https://example.org/", "page_collected",
                         {"content_hash": "a" * 64, "status": 200})
    second = append_event(db, "https://example.org/a", "page_collected",
                          {"content_hash": "b" * 64, "status": 200})
    assert second["previous_hash"] == first["event_hash"]
    result = verify_chain(db)
    assert result["valid"] is True
    assert result["verified_events"] == 2

def test_evidence_chain_detects_payload_tampering(tmp_path):
    db = str(tmp_path / "evidence.sqlite")
    append_event(db, "https://example.org/", "page_collected", {"status": 200})
    con = sqlite3.connect(db)
    con.execute("UPDATE evidence_events SET payload_json='{\"status\":403}' WHERE id=1")
    con.commit()
    con.close()
    result = verify_chain(db)
    assert result["valid"] is False
    assert result["failed_event_id"] == 1
