from wie.extract.html import extract_title_text

def test_extract_title_and_text():
    title, text = extract_title_text("<html><head><title>Demo</title></head><body><main><p>Hello</p></main></body></html>")
    assert title == "Demo"
    assert "Hello" in text
