import pytest
from wie.adapters.scrapy_adapter import same_origin, _scrapy_settings

@pytest.mark.parametrize("candidate", [
    "https://example.org/about",
    "https://example.org:443/about",
])
def test_same_origin_accepts_same_origin(candidate):
    assert same_origin("https://example.org/", candidate)

@pytest.mark.parametrize("candidate", [
    "http://example.org/about",
    "https://sub.example.org/about",
    "https://example.org:8443/about",
    "https://evil.example/about",
])
def test_same_origin_rejects_other_origin(candidate):
    assert not same_origin("https://example.org/", candidate)

def test_scrapy_settings_enable_safety_and_throttling():
    cfg = {"user_agent":"WIE-TestBot","request_delay_seconds":0.2,
           "timeout_seconds":9,"database_path":"data/db.sqlite",
           "raw_dir":"data/raw"}
    settings = _scrapy_settings(cfg)
    assert settings["ROBOTSTXT_OBEY"] is True
    assert settings["AUTOTHROTTLE_ENABLED"] is True
    assert settings["DOWNLOAD_DELAY"] == 1.0
    assert settings["USER_AGENT"] == "WIE-TestBot"
    assert settings["RETRY_HTTP_CODES"] == [500, 502, 503, 504]
    assert "wie.adapters.scrapy_adapter.PublicTargetGuard" in settings["DOWNLOADER_MIDDLEWARES"]
    assert "wie.adapters.scrapy_adapter.RecordPipeline" in settings["ITEM_PIPELINES"]


def test_scrapy_component_paths_resolve():
    from wie.adapters import scrapy_adapter
    settings = _scrapy_settings({
        "user_agent":"WIE", "request_delay_seconds":1,
        "timeout_seconds":10, "database_path":"data/db.sqlite",
        "raw_dir":"data/raw",
    })
    middleware_path = next(iter(settings["DOWNLOADER_MIDDLEWARES"]))
    pipeline_path = next(iter(settings["ITEM_PIPELINES"]))
    assert getattr(scrapy_adapter, middleware_path.rsplit(".", 1)[1]) is scrapy_adapter.PublicTargetGuard
    assert getattr(scrapy_adapter, pipeline_path.rsplit(".", 1)[1]) is scrapy_adapter.RecordPipeline


def test_scrapy_guard_rejects_cross_origin(monkeypatch):
    from types import SimpleNamespace
    from wie.adapters import scrapy_adapter
    pytest.importorskip("scrapy")
    from scrapy.exceptions import IgnoreRequest
    monkeypatch.setattr(scrapy_adapter, "validate_public_http_url", lambda url: True)
    middleware = scrapy_adapter.PublicTargetGuard()
    spider = SimpleNamespace(
        start_url="https://example.org/",
        crawler=SimpleNamespace(stats=SimpleNamespace(inc_value=lambda key: None)),
    )
    request = SimpleNamespace(url="https://other.example/path")
    with pytest.raises(IgnoreRequest):
        middleware.process_request(request, spider)


def test_scrapy_guard_allows_same_origin_after_public_validation(monkeypatch):
    pytest.importorskip("scrapy")
    from types import SimpleNamespace
    from wie.adapters import scrapy_adapter
    monkeypatch.setattr(scrapy_adapter, "validate_public_http_url", lambda url: True)
    middleware = scrapy_adapter.PublicTargetGuard()
    spider = SimpleNamespace(
        start_url="https://example.org/",
        crawler=SimpleNamespace(stats=SimpleNamespace(inc_value=lambda key: None)),
    )
    request = SimpleNamespace(url="https://example.org/path")
    assert middleware.process_request(request, spider) is None
