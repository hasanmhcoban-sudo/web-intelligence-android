import pytest
from wie.storage.history import save_snapshot, list_snapshots, diff_snapshots

def test_snapshot_history_and_diff(tmp_path):
    db = str(tmp_path / "history.sqlite")
    assert save_snapshot(db, "https://example.org/", "hash-a", "Title", "alpha\nbeta", "2026-01-01")
    assert not save_snapshot(db, "https://example.org/", "hash-a", "Title", "alpha\nbeta", "2026-01-02")
    assert save_snapshot(db, "https://example.org/", "hash-b", "Title 2", "alpha\ngamma", "2026-01-03")
    items = list_snapshots(db, "https://example.org/")
    assert len(items) == 2
    result = diff_snapshots(db, items[1]["id"], items[0]["id"])
    assert result["changed"] is True
    assert any("-beta" in line for line in result["diff"])
    assert any("+gamma" in line for line in result["diff"])

def test_diff_rejects_different_urls(tmp_path):
    db = str(tmp_path / "history.sqlite")
    save_snapshot(db, "https://a.example/", "a", "A", "A", "1")
    save_snapshot(db, "https://b.example/", "b", "B", "B", "2")
    items = []
    import sqlite3
    con = sqlite3.connect(db)
    ids = con.execute("select id from page_snapshots order by id").fetchall()
    con.close()
    with pytest.raises(ValueError, match="same source URL"):
        diff_snapshots(db, ids[0][0], ids[1][0])
