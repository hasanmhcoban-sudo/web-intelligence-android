import pytest
from mobile_service import normalize_input_url, app_config

def test_normalize_input_url_adds_https():
    assert normalize_input_url("example.com/path") == "https://example.com/path"

def test_normalize_input_url_accepts_http():
    assert normalize_input_url("http://example.com") == "http://example.com"

@pytest.mark.parametrize("value", ["", "ftp://example.com", "https://user:pass@example.com"])
def test_normalize_input_url_rejects_unsafe_forms(value):
    with pytest.raises(ValueError):
        normalize_input_url(value)

def test_app_config_uses_app_private_directory(tmp_path):
    cfg = app_config(tmp_path / "private")
    assert cfg["respect_robots_txt"] is True
    assert cfg["database_path"].endswith("records.sqlite3")
    assert (tmp_path / "private" / "raw").is_dir()
    assert (tmp_path / "private" / "exports").is_dir()
