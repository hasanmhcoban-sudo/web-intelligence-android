import json
import pytest
from wie.discovery.api import discover_api_candidates, parse_openapi_spec

def test_discover_only_explicit_api_spec_links():
    html = """
    <html><body>
      <a href="/docs/openapi.json">API schema</a>
      <link rel="service-desc" href="/api/service-desc"/>
      <a href="/ordinary-page">ordinary</a>
    </body></html>
    """
    found = discover_api_candidates(html, "https://example.org/")
    assert "https://example.org/docs/openapi.json" in found
    assert "https://example.org/api/service-desc" in found
    assert all("ordinary-page" not in item for item in found)

def test_parse_openapi_json_without_network_access():
    spec = {
        "openapi": "3.0.3",
        "info": {"title": "Sample API", "version": "1.0"},
        "paths": {
            "/items": {"get": {"operationId": "listItems", "summary": "List items"},
                       "post": {"summary": "Create item"}},
            "/health": {"get": {}},
        },
    }
    result = parse_openapi_spec(json.dumps(spec))
    assert result["endpoint_count"] == 3
    assert result["title"] == "Sample API"
    assert result["endpoints"][0]["method"] == "GET"

def test_reject_non_openapi_document():
    with pytest.raises(ValueError, match="does not declare"):
        parse_openapi_spec('{"hello":"world"}')


@pytest.mark.asyncio
async def test_fetch_api_spec_retrieves_only_spec_document(monkeypatch):
    import httpx
    from wie.discovery import api

    monkeypatch.setattr(api, "validate_public_http_url", lambda url: True)
    payload = json.dumps({
        "openapi": "3.0.1",
        "info": {"title": "Public Docs", "version": "1"},
        "paths": {"/records": {"get": {"summary": "List records"}}},
    }).encode()

    async def handler(request):
        assert request.method == "GET"
        assert str(request.url) == "https://example.org/openapi.json"
        return httpx.Response(
            200, headers={"content-type": "application/json"}, content=payload
        )

    result = await api.fetch_api_spec(
        "https://example.org/openapi.json",
        "https://example.org/docs",
        {"user_agent": "WIE-Test", "timeout_seconds": 5,
         "max_response_bytes": 10000},
        transport=httpx.MockTransport(handler),
    )
    assert result["title"] == "Public Docs"
    assert result["endpoint_count"] == 1
    assert result["source_url"] == "https://example.org/openapi.json"


@pytest.mark.asyncio
async def test_fetch_api_spec_rejects_cross_origin_before_request(monkeypatch):
    from wie.discovery.api import fetch_api_spec
    with pytest.raises(ValueError, match="Cross-origin"):
        await fetch_api_spec(
            "https://other.example/openapi.json",
            "https://example.org/",
            {"user_agent": "WIE", "timeout_seconds": 5},
        )


@pytest.mark.asyncio
async def test_fetch_api_spec_rejects_cross_origin_redirect(monkeypatch):
    import httpx
    from wie.discovery import api
    monkeypatch.setattr(api, "validate_public_http_url", lambda url: True)
    calls = []

    async def handler(request):
        calls.append(str(request.url))
        return httpx.Response(302, headers={"location": "https://evil.example/spec.json"})

    with pytest.raises(ValueError, match="Cross-origin API spec redirect"):
        await api.fetch_api_spec(
            "https://example.org/openapi.json",
            "https://example.org/",
            {"user_agent": "WIE", "timeout_seconds": 5},
            transport=httpx.MockTransport(handler),
        )
    assert calls == ["https://example.org/openapi.json"]


@pytest.mark.asyncio
async def test_fetch_api_spec_enforces_response_size(monkeypatch):
    import httpx
    from wie.discovery import api
    monkeypatch.setattr(api, "validate_public_http_url", lambda url: True)

    async def handler(request):
        return httpx.Response(
            200, headers={"content-type": "application/json"},
            content=b'{"openapi":"3.0.0","info":{},"paths":{}}' + b" " * 100,
        )

    with pytest.raises(ValueError, match="exceeded max_response_bytes"):
        await api.fetch_api_spec(
            "https://example.org/openapi.json",
            "https://example.org/",
            {"user_agent": "WIE", "timeout_seconds": 5,
             "max_response_bytes": 32},
            transport=httpx.MockTransport(handler),
        )
