import sys
from types import SimpleNamespace
from wie.extract import documents

def test_pdf_extraction_can_opt_into_ocr(tmp_path, monkeypatch):
    file_path = tmp_path / "scan.pdf"
    file_path.write_bytes(b"fake-pdf")
    class FakePage:
        def extract_text(self):
            return ""
    class FakeReader:
        pages = [FakePage(), FakePage()]
        is_encrypted = False
        def __init__(self, path):
            pass
    monkeypatch.setitem(sys.modules, "pypdf", SimpleNamespace(PdfReader=FakeReader))
    monkeypatch.setattr(
        "wie.extract.ocr.ocr_pdf",
        lambda *args, **kwargs: {
            "pages": [{"page": 1, "text": "OCR text"}],
            "pages_processed": 1, "pages_total": 2,
            "truncated": True, "languages": "tur+eng",
        },
    )
    result = documents.extract_document(
        str(file_path), ocr=True, ocr_languages="tur+eng", ocr_max_pages=1
    )
    assert "OCR text" in result["text"]
    assert result["metadata"]["ocr_used"] is True
    assert result["metadata"]["ocr_truncated"] is True
