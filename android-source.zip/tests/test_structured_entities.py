from wie.extract.structured import (
    extract_jsonld_entities, extract_microdata_entities,
    extract_rdfa_entities, extract_structured_entities,
)
from wie.extract.html import extract_page

def test_jsonld_graph_and_type_normalization():
    html = """<script type="application/ld+json">
    {"@context":"https://schema.org","@graph":[
      {"@type":"https://schema.org/Article","headline":"A headline","datePublished":"2026-01-01"},
      {"@type":"Product","name":"Widget","sku":"W-1","offers":{"price":"10"}}
    ]}</script>"""
    items = extract_jsonld_entities(html)
    assert items[0]["type"] == "Article"
    assert items[0]["name"] == "A headline"
    assert items[1]["properties"]["sku"] == "W-1"

def test_microdata_itemprop_extraction():
    html = """<div itemscope itemtype="https://schema.org/Product">
      <span itemprop="name">Widget</span>
      <meta itemprop="sku" content="W-2">
    </div>"""
    items = extract_microdata_entities(html)
    assert items[0]["name"] == "Widget"
    assert items[0]["properties"]["sku"] == "W-2"

def test_rdfa_property_extraction():
    html = """<div typeof="schema:Article">
      <span property="schema:headline">News title</span>
    </div>"""
    items = extract_rdfa_entities(html)
    assert items[0]["name"] == "News title"

def test_html_pipeline_exposes_structured_entities():
    html = '<html><title>T</title><script type="application/ld+json">{"@type":"Article","headline":"H"}</script></html>'
    result = extract_page(html)
    assert result["structured_entities"][0]["type"] == "Article"

def test_duplicate_structured_entities_deduplicated():
    html = """<script type="application/ld+json">{"@type":"Product","name":"A"}</script>
    <div itemscope itemtype="https://schema.org/Product"><span itemprop="name">A</span></div>"""
    items = extract_structured_entities(html)
    assert len(items) == 1
