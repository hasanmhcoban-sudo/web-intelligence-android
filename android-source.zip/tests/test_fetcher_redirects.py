import asyncio
import httpx
import pytest
from wie.fetchers import http as fetch_module
from wie.fetchers.http import FetchError

class FakeResponse:
    def __init__(self, status, url, headers=None, body="ok"):
        self.status_code = status
        self.url = httpx.URL(url)
        self.headers = headers or {}
        self._body = body
    async def __aenter__(self): return self
    async def __aexit__(self, *args): return False
    def raise_for_status(self):
        if self.status_code >= 400:
            raise httpx.HTTPStatusError("bad status", request=httpx.Request("GET", str(self.url)),
                                        response=httpx.Response(self.status_code))
    async def aiter_text(self):
        yield self._body

class FakeClient:
    def __init__(self, responses, **kwargs):
        self.responses = list(responses)
        self.requested = []
    async def __aenter__(self): return self
    async def __aexit__(self, *args): return False
    def stream(self, method, url):
        self.requested.append(str(url))
        return self.responses.pop(0)

def cfg():
    return {"user_agent":"test","timeout_seconds":1,"max_response_bytes":1000,
            "max_redirects":3,"max_retries":0}

def test_redirect_target_is_revalidated(monkeypatch):
    calls = []
    def validate(url):
        calls.append(url)
        if "127.0.0.1" in url:
            raise fetch_module.UnsafeURLError("private IP")
    monkeypatch.setattr(fetch_module, "validate_public_http_url", validate)
    fake = FakeClient([
        FakeResponse(302, "https://public.example/", {"location":"http://127.0.0.1/admin"})
    ])
    monkeypatch.setattr(fetch_module.httpx, "AsyncClient", lambda **kwargs: fake)
    with pytest.raises(FetchError, match="Unsafe destination"):
        asyncio.run(fetch_module.fetch_http("https://public.example/", cfg()))
    assert calls == ["https://public.example/", "http://127.0.0.1/admin"]

def test_safe_redirect_then_content(monkeypatch):
    calls = []
    monkeypatch.setattr(fetch_module, "validate_public_http_url", lambda url: calls.append(url))
    fake = FakeClient([
        FakeResponse(301, "https://public.example/", {"location":"/next"}),
        FakeResponse(200, "https://public.example/next", body="hello")
    ])
    monkeypatch.setattr(fetch_module.httpx, "AsyncClient", lambda **kwargs: fake)
    html, final_url, status = asyncio.run(fetch_module.fetch_http("https://public.example/", cfg()))
    assert html == "hello"
    assert final_url.endswith("/next")
    assert status == 200
    assert len(calls) == 2
