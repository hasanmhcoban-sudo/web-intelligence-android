import csv, json
from datetime import datetime, timezone
from openpyxl import load_workbook
from wie.models import ExtractedRecord
from wie.storage.db import save_record
from wie.storage.export import export_jsonl, export_csv, export_xlsx

def make_db(tmp_path):
    db = str(tmp_path / "records.sqlite3")
    record = ExtractedRecord(
        source_url="https://example.org",
        collected_at=datetime.now(timezone.utc).isoformat(),
        title="Example", text="Body", content_hash="hash-1",
        metadata={"source": "test"}
    )
    assert save_record(db, record)
    return db

def test_jsonl_export(tmp_path):
    db = make_db(tmp_path)
    out = tmp_path / "out.jsonl"
    export_jsonl(db, str(out))
    row = json.loads(out.read_text(encoding="utf-8").splitlines()[0])
    assert row["title"] == "Example"
    assert row["metadata"]["source"] == "test"

def test_csv_export(tmp_path):
    db = make_db(tmp_path)
    out = tmp_path / "out.csv"
    export_csv(db, str(out))
    with out.open(encoding="utf-8-sig", newline="") as handle:
        rows = list(csv.DictReader(handle))
    assert rows[0]["title"] == "Example"

def test_xlsx_export(tmp_path):
    db = make_db(tmp_path)
    out = tmp_path / "out.xlsx"
    export_xlsx(db, str(out))
    wb = load_workbook(out, read_only=True, data_only=True)
    try:
        rows = list(wb["Records"].values)
        assert rows[1][2] == "Example"
    finally:
        wb.close()
