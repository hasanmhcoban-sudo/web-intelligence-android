from pathlib import Path
import pytest
from wie.extract.documents import extract_document, DocumentExtractionError

def test_text_extract(tmp_path):
    p = tmp_path / "note.txt"
    p.write_text("sample text", encoding="utf-8")
    result = extract_document(str(p))
    assert result["format"] == "txt"
    assert result["text"] == "sample text"

def test_json_extract(tmp_path):
    p = tmp_path / "data.json"
    p.write_text('{"name":"Ada"}', encoding="utf-8")
    result = extract_document(str(p))
    assert '"Ada"' in result["text"]
    assert result["metadata"]["valid_json"] is True

def test_csv_extract(tmp_path):
    p = tmp_path / "data.csv"
    p.write_text("a,b\n1,2\n", encoding="utf-8")
    result = extract_document(str(p))
    assert result["metadata"]["row_count"] == 2
    assert "a | b" in result["text"]

def test_unsupported_format_rejected(tmp_path):
    p = tmp_path / "data.bin"
    p.write_bytes(b"x")
    with pytest.raises(DocumentExtractionError):
        extract_document(str(p))
