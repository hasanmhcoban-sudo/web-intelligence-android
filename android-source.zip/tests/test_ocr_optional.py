import pytest
from wie.extract.ocr import ocr_pdf

def test_ocr_validates_page_limit_before_dependencies():
    with pytest.raises(ValueError, match="max_pages"):
        ocr_pdf("missing.pdf", max_pages=0)

def test_ocr_reports_missing_tesseract(monkeypatch):
    monkeypatch.setattr("wie.extract.ocr.which", lambda name: None)
    with pytest.raises(RuntimeError, match="Tesseract"):
        ocr_pdf("missing.pdf")
