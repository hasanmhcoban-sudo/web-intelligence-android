import json
from wie.models import ExtractedRecord
from wie.storage.db import save_record
from wie.analytics.profile import profile_database

def test_profile_database_reports_quality_metrics(tmp_path):
    db = str(tmp_path / "profile.sqlite")
    save_record(db, ExtractedRecord(
        "https://example.org/a", "2026-11-23T10:00:00+00:00",
        "Title", "some text", "a"*64, "valid", {"mode":"http"}
    ))
    save_record(db, ExtractedRecord(
        "https://example.org/b", "2026-11-23T10:01:00+00:00",
        "", "", "b"*64, "empty", {"mode":"browser"}
    ))
    result = profile_database(db)
    assert result["record_count"] == 2
    assert result["unique_domains"] == 1
    assert result["missing_title_count"] == 1
    assert result["empty_text_count"] == 1
    assert result["text_length"]["max"] == 9
    assert result["common_metadata_keys"][0][0] == "mode"
