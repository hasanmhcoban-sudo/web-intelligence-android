import asyncio
from wie import crawl as crawl_module

def test_crawl_site_uses_limits_and_saves_records(tmp_path, monkeypatch):
    pages = {
        "https://example.org/": '<html><head><title>Home</title></head><body><main>Home<a href="/about">About</a><a href="https://elsewhere.org/x">External</a></main></body></html>',
        "https://example.org/about": '<html><head><title>About</title></head><body><main>About page</main></body></html>',
    }

    from urllib.robotparser import RobotFileParser
    async def fake_policy(url, user_agent, timeout):
        parser = RobotFileParser()
        parser.parse(["User-agent: *", "Disallow: /private"])
        return parser, True

    async def fake_fetch(url, cfg):
        return pages[url], url, 200

    async def fake_sitemap(*args, **kwargs):
        return []

    monkeypatch.setattr(crawl_module, "load_robots_policy", fake_policy)
    monkeypatch.setattr(crawl_module, "fetch_http", fake_fetch)
    monkeypatch.setattr(crawl_module, "discover_sitemap_urls", fake_sitemap)
    monkeypatch.setattr(crawl_module, "validate_public_http_url", lambda url: url)

    cfg = {
        "user_agent": "test",
        "timeout_seconds": 2,
        "request_delay_seconds": 0,
        "respect_robots_txt": True,
        "raw_dir": str(tmp_path / "raw"),
        "database_path": str(tmp_path / "db.sqlite3"),
    }
    result = asyncio.run(crawl_module.crawl_site(
        "https://example.org/", cfg, max_pages=5, max_depth=1, use_sitemap=False
    ))
    assert result["visited"] == 2
    assert result["saved_new_records"] == 2
    assert result["errors"] == []
