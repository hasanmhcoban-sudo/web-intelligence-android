from pathlib import Path
from docx import Document
from openpyxl import Workbook
from pypdf import PdfWriter
from wie.extract.documents import extract_document

def test_docx_extracts_paragraph_and_table(tmp_path):
    path = tmp_path / "sample.docx"
    doc = Document()
    doc.add_paragraph("Document body")
    table = doc.add_table(rows=1, cols=2)
    table.cell(0, 0).text = "A"
    table.cell(0, 1).text = "B"
    doc.save(path)
    result = extract_document(str(path))
    assert "Document body" in result["text"]
    assert result["metadata"]["tables"][0] == [["A", "B"]]

def test_xlsx_extracts_sheet_values(tmp_path):
    path = tmp_path / "sample.xlsx"
    wb = Workbook()
    ws = wb.active
    ws.title = "Metrics"
    ws.append(["Name", "Value"])
    ws.append(["Visits", 42])
    wb.save(path)
    result = extract_document(str(path))
    assert result["format"] == "xlsx"
    assert "Visits | 42" in result["text"]
    assert "Metrics" in result["metadata"]["sheets"]

def test_pdf_empty_text_layer_is_reported_without_crash(tmp_path):
    path = tmp_path / "sample.pdf"
    writer = PdfWriter()
    writer.add_blank_page(width=72, height=72)
    with path.open("wb") as handle:
        writer.write(handle)
    result = extract_document(str(path))
    assert result["format"] == "pdf"
    assert result["metadata"]["page_count"] == 1
