from urllib.robotparser import RobotFileParser

def test_robots_rules_are_path_specific():
    parser = RobotFileParser()
    parser.parse(["User-agent: *", "Disallow: /private"])
    assert parser.can_fetch("WebIntelligenceEngine", "https://example.org/public")
    assert not parser.can_fetch("WebIntelligenceEngine", "https://example.org/private/data")
