import pytest
from wie.config import load_config

def test_defaults_load_without_file(tmp_path):
    cfg = load_config(str(tmp_path / "missing.yaml"))
    assert cfg["respect_robots_txt"] is True
    assert cfg["request_delay_seconds"] >= 0

def test_negative_delay_rejected(tmp_path):
    p = tmp_path / "bad.yaml"
    p.write_text("request_delay_seconds: -1", encoding="utf-8")
    with pytest.raises(ValueError):
        load_config(str(p))
