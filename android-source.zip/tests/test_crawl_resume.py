import asyncio
from wie import crawl as crawl_module

def test_crawl_can_pause_and_resume_durable_queue(tmp_path, monkeypatch):
    pages = {
        "https://example.org/": '<html><title>Home</title><body><a href="/a">A</a></body></html>',
        "https://example.org/a": '<html><title>Page A</title><body>A</body></html>',
    }
    fetched = []
    async def fake_policy(url, user_agent, timeout):
        from urllib.robotparser import RobotFileParser
        parser = RobotFileParser()
        parser.parse(["User-agent: *", "Allow: /"])
        return parser, True
    async def fake_fetch(url, cfg):
        fetched.append(url)
        return pages[url], url, 200
    async def no_sitemap(*args, **kwargs):
        return []
    monkeypatch.setattr(crawl_module, "load_robots_policy", fake_policy)
    monkeypatch.setattr(crawl_module, "fetch_http", fake_fetch)
    monkeypatch.setattr(crawl_module, "discover_sitemap_urls", no_sitemap)
    monkeypatch.setattr(crawl_module, "validate_public_http_url", lambda url: url)
    cfg = {
        "user_agent": "test", "timeout_seconds": 2, "request_delay_seconds": 0,
        "respect_robots_txt": True, "raw_dir": str(tmp_path / "raw"),
        "database_path": str(tmp_path / "db.sqlite"),
    }

    first = asyncio.run(crawl_module.crawl_site(
        "https://example.org/", cfg, max_pages=1, max_depth=2,
        use_sitemap=False, run_id="resume-test"
    ))
    assert first["run_status"] == "paused"
    assert first["queue"]["pending"] == 1
    assert first["visited_this_call"] == 1

    second = asyncio.run(crawl_module.crawl_site(
        "https://example.org/", cfg, max_pages=5, max_depth=2,
        use_sitemap=False, run_id="resume-test", resume=True
    ))
    assert second["run_status"] == "completed"
    assert second["queue"]["done"] == 2
    assert fetched == ["https://example.org/", "https://example.org/a"]

def test_resume_rejects_different_start_url(tmp_path):
    from wie.storage.queue import create_run
    db = str(tmp_path / "db.sqlite")
    create_run(db, "known", "https://example.org/")
    cfg = {"database_path": db, "raw_dir": str(tmp_path / "raw")}
    import pytest
    with pytest.raises(ValueError, match="does not match"):
        asyncio.run(crawl_module.crawl_site(
            "https://other.example/", cfg, run_id="known", resume=True
        ))
