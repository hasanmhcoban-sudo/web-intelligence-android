import asyncio
from types import SimpleNamespace
from wie.discovery import sitemap as sitemap_module


def test_sitemap_fetch_does_not_follow_redirects(monkeypatch):
    calls = []

    class FakeResponse:
        status_code = 302
        content = b""

    class FakeClient:
        def __init__(self, *args, **kwargs):
            assert kwargs.get("follow_redirects") is False
        async def __aenter__(self):
            return self
        async def __aexit__(self, *args):
            return False
        async def get(self, url):
            calls.append(url)
            return FakeResponse()

    monkeypatch.setattr(sitemap_module, "validate_public_http_url", lambda url: url)
    monkeypatch.setattr(sitemap_module.httpx, "AsyncClient", FakeClient)
    result = asyncio.run(sitemap_module.discover_sitemap_urls(
        "https://public.example/", "test-agent", max_urls=10
    ))
    assert result == []
    assert calls == ["https://public.example/sitemap.xml", "https://public.example/sitemap_index.xml"]


def test_crawl_seed_private_ip_is_rejected_before_policy_request(tmp_path, monkeypatch):
    from wie import crawl as crawl_module
    from wie.policy.url_safety import UnsafeURLError
    import pytest

    async def should_not_fetch_policy(*args, **kwargs):
        raise AssertionError("robots request must not happen for a private IP")

    monkeypatch.setattr(crawl_module, "load_robots_policy", should_not_fetch_policy)
    cfg = {
        "user_agent": "test", "timeout_seconds": 2, "request_delay_seconds": 0,
        "respect_robots_txt": True, "raw_dir": str(tmp_path / "raw"),
        "database_path": str(tmp_path / "db.sqlite"),
    }
    with pytest.raises(UnsafeURLError):
        asyncio.run(crawl_module.crawl_site("http://127.0.0.1/", cfg, use_sitemap=False))
