from datetime import datetime, timezone
from wie.models import ExtractedRecord
from wie.storage.db import save_record, connect

def test_duplicate_url_and_hash_is_ignored(tmp_path):
    db = str(tmp_path / "test.sqlite3")
    rec = ExtractedRecord(
        source_url="https://example.org",
        collected_at=datetime.now(timezone.utc).isoformat(),
        title="Example", text="Hello", content_hash="abc"
    )
    assert save_record(db, rec) is True
    assert save_record(db, rec) is False
    con = connect(db)
    try:
        assert con.execute("SELECT COUNT(*) FROM records").fetchone()[0] == 1
    finally:
        con.close()
