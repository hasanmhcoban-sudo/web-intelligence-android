import sqlite3
import pytest
from wie.storage.queue import (
    create_run, enqueue_jobs, recover_interrupted_jobs, claim_next_job,
    finish_job, queue_stats, get_run,
)

def test_queue_deduplicates_and_tracks_job_lifecycle(tmp_path):
    db = str(tmp_path / "q.sqlite")
    create_run(db, "r1", "https://example.org/")
    assert enqueue_jobs(db, "r1", [("https://example.org/a", 1),
                                    ("https://example.org/a", 1)]) == 1
    job = claim_next_job(db, "r1")
    assert job["url"] == "https://example.org/"
    finish_job(db, job["id"], "done")
    job2 = claim_next_job(db, "r1")
    assert job2["url"] == "https://example.org/a"
    finish_job(db, job2["id"], "error", "test failure")
    assert queue_stats(db, "r1") == {
        "pending": 0, "in_progress": 0, "done": 1, "error": 1, "blocked": 0
    }

def test_interrupted_jobs_are_requeued(tmp_path):
    db = str(tmp_path / "q.sqlite")
    create_run(db, "r2", "https://example.org/")
    job = claim_next_job(db, "r2")
    assert job
    assert recover_interrupted_jobs(db, "r2") == 1
    assert queue_stats(db, "r2")["pending"] == 1
    assert claim_next_job(db, "r2")["url"] == "https://example.org/"

def test_run_metadata_persists(tmp_path):
    db = str(tmp_path / "q.sqlite")
    create_run(db, "r3", "https://example.org/")
    run = get_run(db, "r3")
    assert run["start_url"] == "https://example.org/"
    assert run["status"] == "running"
