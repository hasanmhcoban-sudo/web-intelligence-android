import pytest
from wie.models import ExtractedRecord
from wie.quality.normalize import normalize_record, normalize_text

def make_record(**overrides):
    values = {
        "source_url": "https://example.org/path",
        "collected_at": "2026-11-23T10:00:00+00:00",
        "title": "  Cafe\u0301   title ",
        "text": " line one\n\n line two ",
        "content_hash": "a" * 64,
        "status": "valid",
        "metadata": {"source": "test"},
    }
    values.update(overrides)
    return ExtractedRecord(**values)

def test_record_text_normalization_is_unicode_and_whitespace_safe():
    result = normalize_record(make_record())
    assert result.title == "Café title"
    assert result.text == "line one line two"
    assert result.metadata["normalization"]["normalizer_version"] == "1.0"

@pytest.mark.parametrize("url", ["file:///etc/passwd", "http://user:pass@example.org", "/relative"])
def test_rejects_invalid_source_urls(url):
    with pytest.raises(ValueError):
        normalize_record(make_record(source_url=url))

def test_rejects_bad_hash_and_timezone():
    with pytest.raises(ValueError, match="SHA-256"):
        normalize_record(make_record(content_hash="bad"))
    with pytest.raises(ValueError, match="timezone"):
        normalize_record(make_record(collected_at="2026-11-23T10:00:00"))

def test_metadata_must_be_json_persistable_and_bounded():
    with pytest.raises(ValueError, match="mapping"):
        normalize_record(make_record(metadata=[]))
    with pytest.raises(TypeError):
        normalize_record(make_record(metadata={"bad": object()}))

def test_normalize_text_limits_length():
    assert normalize_text("abcdef", 3) == "abc"
