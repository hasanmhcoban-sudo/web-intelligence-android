import socket
import pytest
from wie.policy.url_safety import validate_public_http_url, UnsafeURLError

def fake_public(host, port, type):
    return [(socket.AF_INET, socket.SOCK_STREAM, 6, "", ("93.184.216.34", port))]

def fake_private(host, port, type):
    return [(socket.AF_INET, socket.SOCK_STREAM, 6, "", ("127.0.0.1", port))]

def test_public_domain_allowed():
    assert validate_public_http_url("https://example.org", resolver=fake_public)

@pytest.mark.parametrize("url", [
    "file:///etc/passwd",
    "ftp://example.org",
    "http://localhost/admin",
    "http://127.0.0.1/",
    "http://user:pass@example.org/",
])
def test_unsafe_syntax_or_local_address_rejected(url):
    with pytest.raises(UnsafeURLError):
        validate_public_http_url(url, resolver=fake_public)

def test_private_dns_result_rejected():
    with pytest.raises(UnsafeURLError):
        validate_public_http_url("https://internal.example", resolver=fake_private)

def test_mixed_public_private_dns_answers_rejected():
    def mixed(host, port, type):
        return [
            (socket.AF_INET, socket.SOCK_STREAM, 6, "", ("93.184.216.34", port)),
            (socket.AF_INET, socket.SOCK_STREAM, 6, "", ("10.0.0.8", port)),
        ]
    with pytest.raises(UnsafeURLError):
        validate_public_http_url("https://mixed.example", resolver=mixed)
