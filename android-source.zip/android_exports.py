"""Copy exported files into the public Android Downloads collection (Android 10+)."""
from __future__ import annotations

from pathlib import Path


def publish_to_downloads(source_path: str | Path, display_name: str, mime_type: str) -> str:
    source = Path(source_path)
    data = source.read_bytes()
    try:
        from jnius import autoclass

        BuildVersion = autoclass("android.os.Build$VERSION")
        if int(BuildVersion.SDK_INT) < 29:
            raise RuntimeError("Public Downloads export requires Android 10 or newer.")

        PythonActivity = autoclass("org.kivy.android.PythonActivity")
        MediaStoreDownloads = autoclass("android.provider.MediaStore$Downloads")
        MediaColumns = autoclass("android.provider.MediaStore$MediaColumns")
        ContentValues = autoclass("android.content.ContentValues")

        activity = PythonActivity.mActivity
        resolver = activity.getContentResolver()
        values = ContentValues()
        values.put(MediaColumns.DISPLAY_NAME, display_name)
        values.put(MediaColumns.MIME_TYPE, mime_type)
        values.put(MediaColumns.RELATIVE_PATH, "Download/WebIntelligence")
        uri = resolver.insert(MediaStoreDownloads.EXTERNAL_CONTENT_URI, values)
        if uri is None:
            raise RuntimeError("Android Downloads kaydı oluşturulamadı.")
        stream = resolver.openOutputStream(uri)
        if stream is None:
            raise RuntimeError("Android dosya akışı açılamadı.")
        try:
            stream.write(data)
            stream.flush()
        finally:
            stream.close()
        return f"Download/WebIntelligence/{display_name}"
    except ImportError:
        # Desktop smoke tests use the private app export folder.
        return str(source)
