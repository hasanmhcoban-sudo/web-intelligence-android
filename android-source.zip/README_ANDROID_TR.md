# WEB INTELLIGENCE — Android Uygulama 1.0

Bu klasör, mevcut `wie/` veri toplama motorunu Kivy tabanlı Android arayüzüne bağlar.

## Android ilk sürüm

- HTTP/HTTPS web adresi taraması
- Sayfa limiti: 1–30
- Tarama derinliği: 0–2
- robots.txt politikasına uyum (zorunlu)
- 401, 403 ve 429 yanıtlarında durma; korumayı aşmaya çalışma yok
- Yerel SQLite kayıtları ve son kayıt listesi
- Android Downloads/WebIntelligence konumuna CSV ve JSONL dışa aktarma
- Samsung Galaxy A16 için ARM64 debug APK hedefi
- Android 10 ve üzeri hedef; Samsung Galaxy A16 (arm64) için arm64-v8a paketi

## APK nasıl oluşturulur?

Buildozer'ın resmi Kivy dokümantasyonuna göre APK derleme ortamı Linux/macOS veya Windows üzerinde WSL gerektirir. Telefon içindeki mevcut Termux kurulumunda derleme yapmaya çalışmayın.

En kolay derleme yolu bu depoyu GitHub'a yüklemek ve GitHub Actions kullanmaktır:

1. GitHub'da yeni bir repository oluşturun.
2. Bu proje klasörünün **içindeki tüm dosyaları** repository köküne yükleyin. `.github/workflows/build-apk.yml` dosyasının da repository'de bulunduğunu doğrulayın.
3. Repository'de **Actions** sekmesine girin.
4. Solda **Build Web Intelligence APK** iş akışını seçin.
5. **Run workflow** düğmesine basın.
6. İşlem başarılı olunca tamamlanan workflow sayfasının altındaki **Artifacts** bölümünden `web-intelligence-android-debug-apk` dosyasını indirin.
7. ZIP'i açın, içindeki APK dosyasına dokunun ve Android'in kurulum ekranını izleyin.

İlk derleme Android SDK/NDK indirdiğinden uzun sürebilir. Bu kaynak paketi APK'nın derlendiği veya cihazda test edildiği anlamına gelmez; gerçek APK yalnızca başarılı GitHub Actions derlemesinden sonra oluşur.

## Yerel test

Python 3.10+ olan Linux/macOS ortamında:

```bash
python -m pip install -r requirements.txt
python -m pytest -q
```

Kivy arayüzünü masaüstünde test etmek için ayrıca `python -m pip install kivy==2.3.1` kurup `python main.py` çalıştırabilirsiniz.

## Veri konumu

Tarama veritabanı, ham HTML ve uygulama içi dışa aktarma dosyaları Android'in uygulamaya özel veri alanında tutulur. CSV ve JSONL dışa aktarımları Android 10+ cihazlarda `Download/WebIntelligence` klasörüne kopyalanır.

## Güvenlik sınırları

- Yalnız HTTP/HTTPS URL kabul edilir.
- Localhost, özel IP aralıkları ve DNS ile özel IP'ye çözülen alan adları reddedilir.
- Robots.txt alınamazsa politika bilinmiyor kabul edilir ve tarama engellenir.
- Uygulama giriş, üyelik, CAPTCHA, 401/403/429 veya erişim kontrollerini aşmayı denemez.
- İstekler arası bekleme 1,5 saniyedir; sayfa ve derinlik limitleri uygulama arayüzünde sınırlandırılmıştır.

## Android ilk sürüm kapsamı

Mobil ilk sürüm; HTML sayfaları, metadata, JSON-LD/structured entities, SQLite, tarama kuyruğu ve CSV/JSONL çıktısını kapsar. DOCX/XLSX/PDF belge içe aktarma, OCR, Playwright, Scrapy ve gelişmiş API spec keşfi ilk APK kapsamına alınmamıştır; bunlar masaüstü/sonraki Android sürümü için ayrı bağımlılık ve test gerektirir.

## Durum

Kaynak kod, Android UI, Buildozer ayarları, ikon ve GitHub Actions iş akışı hazırlandı. Yerel ortamda Python testleri **86 passed, 2 skipped** ve sözdizimi kontrolü başarılıdır. Henüz Android SDK/NDK derlemesi çalıştırılmadı; APK çıktısı ve gerçek cihaz doğrulaması bekliyor.
