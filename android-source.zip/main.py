"""Kivy Android interface for Web Intelligence & Data Extraction Engine."""
from __future__ import annotations

import threading
from pathlib import Path
from urllib.parse import urlsplit

from kivy.app import App
from kivy.clock import Clock
from kivy.metrics import dp
from kivy.core.window import Window
from kivy.graphics import Color, RoundedRectangle
from kivy.uix.boxlayout import BoxLayout
from kivy.uix.button import Button
from kivy.uix.label import Label
from kivy.uix.scrollview import ScrollView
from kivy.uix.textinput import TextInput

from mobile_service import create_export, recent_records, run_mobile_crawl
from android_exports import publish_to_downloads


BG = (0.035, 0.055, 0.075, 1)
PANEL = (0.075, 0.105, 0.135, 1)
TEXT = (0.91, 0.95, 0.98, 1)
MUTED = (0.61, 0.69, 0.75, 1)
ACCENT = (0.12, 0.72, 0.61, 1)


class Surface(BoxLayout):
    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        with self.canvas.before:
            Color(*PANEL)
            self._rect = RoundedRectangle(pos=self.pos, size=self.size, radius=[dp(16)])
        self.bind(pos=self._sync_rect, size=self._sync_rect)

    def _sync_rect(self, *_):
        self._rect.pos = self.pos
        self._rect.size = self.size


class WebIntelligenceApp(App):
    title = "Web Intelligence"

    def build(self):
        Window.clearcolor = BG
        Window.softinput_mode = "below_target"
        self._scan_running = False
        self.data_dir = Path(self.user_data_dir)
        self.data_dir.mkdir(parents=True, exist_ok=True)

        scroll = ScrollView(do_scroll_x=False, bar_width=dp(3))
        content = BoxLayout(
            orientation="vertical", padding=[dp(18), dp(18)], spacing=dp(13),
            size_hint_y=None,
        )
        content.bind(minimum_height=content.setter("height"))
        scroll.add_widget(content)

        brand = Label(
            text="[b]WEB INTELLIGENCE[/b]\n[size=13sp]DATA EXTRACTION ENGINE 1.0[/size]",
            markup=True, color=TEXT, halign="left", valign="middle",
            size_hint_y=None, height=dp(76), font_size="22sp",
        )
        content.add_widget(brand)

        info = Label(
            text="Kamuya açık web sayfalarını güvenli kurallarla tara ve kayıt altına al.",
            color=MUTED, halign="left", valign="middle", size_hint_y=None,
            height=dp(42), font_size="14sp",
        )
        content.add_widget(info)

        card = Surface(orientation="vertical", padding=dp(14), spacing=dp(10),
                       size_hint_y=None, height=dp(222))
        card.add_widget(self._field_label("WEB SİTESİ ADRESİ"))
        self.url_input = TextInput(
            hint_text="https://example.com", multiline=False, size_hint_y=None,
            height=dp(48), font_size="16sp", foreground_color=TEXT,
            hint_text_color=MUTED, background_normal="", background_active="",
            background_color=(0.12, 0.16, 0.19, 1), cursor_color=ACCENT,
            padding=[dp(12), dp(13)],
        )
        card.add_widget(self.url_input)

        row = BoxLayout(orientation="horizontal", spacing=dp(10), size_hint_y=None, height=dp(65))
        left = BoxLayout(orientation="vertical", spacing=dp(4))
        left.add_widget(self._field_label("SAYFA LİMİTİ (1–30)"))
        self.pages_input = self._number_input("10")
        left.add_widget(self.pages_input)
        right = BoxLayout(orientation="vertical", spacing=dp(4))
        right.add_widget(self._field_label("DERİNLİK (0–2)"))
        self.depth_input = self._number_input("1")
        right.add_widget(self.depth_input)
        row.add_widget(left)
        row.add_widget(right)
        card.add_widget(row)
        content.add_widget(card)

        self.scan_button = Button(
            text="TARAMAYI BAŞLAT", size_hint_y=None, height=dp(54),
            background_normal="", background_down="", background_color=ACCENT,
            color=(0.02, 0.08, 0.08, 1), bold=True, font_size="16sp",
        )
        self.scan_button.bind(on_release=self.start_scan)
        content.add_widget(self.scan_button)

        policy = Label(
            text="[color=91A7B4]robots.txt kurallarına uyulur • 401/403/429 yanıtlarında durur • özel ağ adresleri engellenir[/color]",
            markup=True, halign="left", valign="middle", size_hint_y=None,
            height=dp(44), font_size="11sp",
        )
        content.add_widget(policy)

        status_card = Surface(orientation="vertical", padding=dp(14), spacing=dp(8),
                              size_hint_y=None, height=dp(115))
        status_card.add_widget(self._field_label("DURUM"))
        self.status_label = Label(
            text="Hazır. Taramak istediğin web sitesini gir.", color=TEXT,
            halign="left", valign="top", font_size="14sp",
        )
        self.status_label.bind(size=lambda w, *_: setattr(w, "text_size", (w.width, None)))
        status_card.add_widget(self.status_label)
        content.add_widget(status_card)

        records_card = Surface(orientation="vertical", padding=dp(14), spacing=dp(8),
                               size_hint_y=None, height=dp(240))
        records_card.add_widget(self._field_label("SON KAYITLAR"))
        self.records_label = Label(
            text="Henüz kayıt yok.", color=TEXT, halign="left", valign="top",
            font_size="12sp",
        )
        self.records_label.bind(size=lambda w, *_: setattr(w, "text_size", (w.width, None)))
        records_card.add_widget(self.records_label)
        content.add_widget(records_card)

        exports = BoxLayout(size_hint_y=None, height=dp(48), spacing=dp(10))
        csv_button = self._secondary_button("CSV İNDİR")
        csv_button.bind(on_release=lambda *_: self.export_records("csv"))
        json_button = self._secondary_button("JSONL İNDİR")
        json_button.bind(on_release=lambda *_: self.export_records("jsonl"))
        exports.add_widget(csv_button)
        exports.add_widget(json_button)
        content.add_widget(exports)

        footer = Label(
            text="WEB INTELLIGENCE • Yerel SQLite kayıtları • Açık kaynak bileşenler",
            color=MUTED, halign="center", size_hint_y=None, height=dp(34), font_size="10sp",
        )
        content.add_widget(footer)
        self._refresh_records()
        return scroll

    def _field_label(self, text):
        return Label(text=text, color=MUTED, halign="left", valign="middle",
                     size_hint_y=None, height=dp(20), font_size="11sp", bold=True)

    def _number_input(self, default):
        return TextInput(text=default, multiline=False, input_filter="int",
                         size_hint_y=None, height=dp(40), font_size="16sp",
                         foreground_color=TEXT, background_normal="", background_active="",
                         background_color=(0.12, 0.16, 0.19, 1), padding=[dp(10), dp(9)])

    def _secondary_button(self, text):
        return Button(text=text, background_normal="", background_down="",
                      background_color=(0.15, 0.22, 0.27, 1), color=TEXT,
                      font_size="12sp", bold=True)

    def _set_status(self, text):
        self.status_label.text = text

    def start_scan(self, *_):
        if self._scan_running:
            return
        url = self.url_input.text.strip()
        if not url:
            self._set_status("Bir web sitesi adresi gir.")
            return
        try:
            pages = int(self.pages_input.text or "10")
            depth = int(self.depth_input.text or "1")
            if not 1 <= pages <= 30 or not 0 <= depth <= 2:
                raise ValueError
        except ValueError:
            self._set_status("Sayfa limiti 1–30, derinlik 0–2 arasında olmalı.")
            return

        self._scan_running = True
        self.scan_button.disabled = True
        self._set_status("Tarama başladı. robots.txt ve adres güvenliği kontrol ediliyor…")
        threading.Thread(target=self._scan_worker, args=(url, pages, depth), daemon=True).start()

    def _scan_worker(self, url, pages, depth):
        try:
            result = run_mobile_crawl(url, pages, depth, self.data_dir)
            Clock.schedule_once(lambda _dt: self._scan_finished(result=result), 0)
        except Exception as exc:
            message = str(exc)[:450]
            Clock.schedule_once(lambda _dt: self._scan_finished(error=message), 0)

    def _scan_finished(self, result=None, error=None):
        self._scan_running = False
        self.scan_button.disabled = False
        if error:
            self._set_status("Tarama tamamlanamadı: " + error)
        else:
            self._set_status(
                f"Tamamlandı • Yeni kayıt: {result.get('saved_new_records', 0)} • "
                f"Ziyaret: {result.get('visited_this_call', 0)} • "
                f"Engellenen: {len(result.get('blocked_by_policy', []))} • "
                f"Hata: {len(result.get('errors', []))}"
            )
        self._refresh_records()

    def _refresh_records(self):
        try:
            rows = recent_records(self.data_dir, 8)
            if not rows:
                self.records_label.text = "Henüz kayıt yok. İlk taramadan sonra sonuçlar burada görünür."
                return
            lines = []
            for row in rows:
                title = (row.get("title") or "Başlıksız sayfa").replace("\n", " ")
                host = urlsplit(row.get("source_url", "")).netloc
                lines.append(f"• {title[:58]}\n  {host}")
            self.records_label.text = "\n\n".join(lines)
        except Exception:
            self.records_label.text = "Kayıt listesi şu anda okunamadı."

    def export_records(self, fmt):
        try:
            path = create_export(self.data_dir, fmt)
            name = path.name
            mime = "text/csv" if fmt == "csv" else "application/x-ndjson"
            destination = publish_to_downloads(path, name, mime)
            self._set_status(f"Dışa aktarıldı: {destination}")
        except Exception as exc:
            self._set_status("Dışa aktarma hatası: " + str(exc)[:350])


if __name__ == "__main__":
    WebIntelligenceApp().run()
