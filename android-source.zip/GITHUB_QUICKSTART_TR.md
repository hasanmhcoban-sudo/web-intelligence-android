# APK üretimi — telefondan hızlı yöntem

Bu yöntem APK'yı telefonda derlemez. GitHub Actions, Buildozer'ı bir Linux sunucusunda çalıştırır.

1. GitHub'da yeni bir **private repository** oluşturun.
2. Bu paketteki `web_intelligence_android_source.zip` dosyasını repository köküne yükleyin.
3. GitHub'da **Add file → Create new file** seçin.
4. Dosya adını tam olarak `.github/workflows/build-apk.yml` yazın.
5. Bu paketteki `GITHUB_BUILD_APK_WORKFLOW.yml` dosyasının içeriğini yeni dosyaya kopyalayıp yapıştırın ve commit edin.
6. **Actions** sekmesine gidin → **Build Web Intelligence APK** → **Run workflow**.
7. İşlem tamamlandığında workflow sayfasındaki **Artifacts** bölümünden `web-intelligence-android-debug-apk` arşivini indirin.
8. İndirdiğiniz arşivi açın, APK'ya dokunun ve Android kurulum adımlarını izleyin.

İlk derleme SDK/NDK indirdiği için uzayabilir. Bu adımlar tamamlanmadan APK hazır sayılmaz.
