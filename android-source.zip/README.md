# Web Intelligence & Data Extraction Engine 1.0

Ücretsiz/açık kaynak araçlarla yerel çalışmaya yönelik modüler web veri çıkarma MVP'si.

## Tasarım ilkeleri
- Önce resmî API; ardından izin verilen HTML kaynakları.
- HTTPX ile statik içerik, isteğe bağlı Playwright ile JavaScript sayfaları.
- robots.txt kontrolü varsayılan olarak açık.
- İstek aralığı, zaman aşımı ve sınırlı retry.
- Ham HTML ve normalize edilmiş kayıtları ayrı saklama.
- Kaynak URL, UTC toplama zamanı, SHA-256 ve doğrulama durumu.
- 401/403/429, CAPTCHA veya erişim engellerini aşmaya çalışma yok.

## Kurulum

Python 3.11+ önerilir.

```bash
python -m venv .venv
# Windows:
.venv\Scripts\activate
# Linux/macOS:
source .venv/bin/activate

pip install -r requirements.txt
cp config/settings.example.yaml config/settings.yaml
```

Playwright tarayıcı motoru isteğe bağlıdır:

```bash
pip install playwright
playwright install chromium
```

## Kullanım

Statik sayfa:
```bash
python -m wie.cli fetch https://example.com --mode http
```

JavaScript sayfası (Playwright kurulu olmalı):
```bash
python -m wie.cli fetch https://example.com --mode browser
```

JSON Lines çıktısı:
```bash
python -m wie.cli export --format jsonl
```

## Dosya yapısı

- `wie/fetchers/`: HTTPX ve Playwright alıcıları
- `wie/policy/`: robots.txt ve istek hızı politikası
- `wie/extract/`: HTML başlık/metin çıkarımı
- `wie/storage/`: SQLite, ham HTML, JSONL dışa aktarımı
- `wie/quality/`: hash ve veri kalite kontrolleri
- `tests/`: temel otomatik testler

## Sınırlamalar
Bu MVP genel amaçlı her siteyi kusursuz çıkarmaz. Siteye özel seçiciler, resmi API adaptörleri,
sayfalama stratejileri ve veri şemaları hedef siteye göre geliştirilmelidir. Ücretli servis
veya kredi kullanan entegrasyon içermez. Yazılım ücretsiz olsa da bilgisayar/sunucu kaynakları
ve internet bağlantısı maliyet doğurabilir.


## Güvenli kullanım kontrol listesi
1. Yalnızca erişim yetkin bulunan veya kamuya açık şekilde sunulan kaynakları hedefle.
2. Site kullanım şartlarını ve ilgili mevzuatı incele.
3. İstek hızını düşük tut; 429 yanıtında dur ve tekrar denemeyi zorlamadan önce bekle.
4. 401/403, CAPTCHA ve erişim kontrolü engellerini aşmaya çalışma.
5. Kişisel/hassas verileri gereksiz yere toplama; gerekiyorsa maskele ve saklama süresini sınırla.
6. Tarama sonuçlarını otomatik olarak gerçek/doğru kabul etme; örnekleme ve kaynak doğrulaması yap.


## Çoklu sayfa tarama

```bash
python -m wie.cli crawl https://example.com --max-pages 30 --max-depth 2
```

Sitemap keşfini kapatmak için `--no-sitemap` kullan. Tarama varsayılan olarak aynı origin
ile sınırlıdır; dış alan adlarına geçmez. Bu sürüm sitemap index içindeki alt sitemap'leri
özyinelemeli çözmez ve JavaScript bağlantı keşfi yapmaz.


## Yapılandırılmış metadata çıkarımı
HTML içinden Open Graph/meta alanları, canonical URL ve JSON-LD blokları çıkarılır.
JSON-LD ayrıştırılamazsa sayfa taraması durmaz; geçersiz blok atlanır.
Çapraz-origin yönlendirmeler çoklu tarama politikasında reddedilir.


## Veri kalite puanı
Kayıt metadata alanında 0–100 aralıklı ağırlıklı kalite puanı tutulur:
`Q = 0.30C + 0.25V + 0.20S + 0.15U + 0.10T`.
Mevcut crawler'daki kaynak güvenilirliği (S=70) geçici nötr varsayımdır; gerçek kaynak
incelemesi yapılmadan güvenilirlik kanıtı sayılmaz. Bu puan bir doğruluk garantisi değildir.


Sitemap index dosyaları sınırlı sayıda alt sitemap'e kadar takip edilir. Tarama, aynı
host dışındaki sitemap girdilerini yok sayar. Robots.txt kontrol sonucu aynı origin için
tarama oturumu boyunca önbelleğe alınır.


## Operasyonel kontrol listesi
- İlk denemeyi küçük `--max-pages` ve `--max-depth` değerleriyle yap.
- Hedef sitenin kullanım şartlarını ve veri koruma yükümlülüklerini kontrol et.
- 401/403/429 yanıtında taramayı durdur; IP/proxy değiştirme veya CAPTCHA çözme yoluna gitme.
- Ham HTML arşivinin disk kullanımını izle; saklama süresi belirle.
- JSON-LD/meta alanlarını doğrulanmış gerçek olarak değil, kaynak beyanı olarak değerlendir.
- `quality_score` yalnızca önceliklendirme sinyalidir; kaynak güvenilirliği otomatik doğrulanmış değildir.

## Henüz uygulanmayan kapsam
Bu sürümde Scrapy/Crawlee adaptörleri, çoklu eşzamanlı tarama, PDF OCR, login/session
işlemleri, proxy havuzu, dağıtık kuyruk ve yönetim paneli yoktur. Ücretli/kredili servis
bağımlılığı eklenmemiştir. Bu özellikler ayrı test ve güvenlik incelemesi gerektirir.


## SSRF / hedef URL güvenliği
HTTP fetch katmanı localhost, özel, loopback, link-local, multicast, reserved ve
unspecified IP hedeflerini reddeder. Her HTTP yönlendirmesinin hedefi yeniden doğrulanır;
kimlik bilgisi içeren URL'ler ve HTTP dışı şemalar kabul edilmez. Bu kontrol DNS rebinding
riskini tek başına ortadan kaldırmaz: üretim ortamında ayrıca outbound firewall/egress
policy uygulanmalı ve yalnızca izin verilen hedeflere ağ çıkışı tanınmalıdır.


HTTP hata yönetimi: 5xx ve ağ/zaman aşımı hataları sınırlı retry/backoff uygular.
401/403/429 yanıtlarında otomatik tekrar veya engel aşma yapılmaz. Yönlendirmeler
otomatik izlenmez; her hedef ayrı doğrulanır ve maksimum yönlendirme sayısı sınırlıdır.


## Yerel belge çıkarımı
`wie.extract.documents.extract_document(path)` TXT, Markdown, HTML, JSON, CSV, PDF,
DOCX ve XLSX dosyalarından içerik çıkarır. PDF/DOCX/XLSX bağımlılıkları ücretsiz ve
açık kaynak Python paketleridir. Taranmış PDF görüntülerinde OCR bu aşamada dahil değildir;
metin katmanı olmayan sayfalar boş metin döndürebilir.


## Dışa aktarma
```bash
python -m wie.cli export --format jsonl
python -m wie.cli export --format csv
python -m wie.cli export --format xlsx
```
CSV UTF-8 BOM ile yazılır; XLSX dışa aktarma ücretsiz `openpyxl` paketini kullanır.


Robots.txt politikası origin başına bir kez yüklenir; izin kararı her URL'nin kendi
path'i için ayrı hesaplanır. Robots.txt alınamazsa (404 hariç) politika bilinmiyor
kabul edilir ve ilgili URL taranmaz.


## İsteğe bağlı Scrapy motoru
Scrapy varsayılan bağımlılık değildir. Ücretsiz/açık kaynak motoru ayrıca kurmak için:
```bash
pip install -r requirements-scrapy.txt
python -m wie.cli crawl https://example.org --engine scrapy --max-pages 50 --max-depth 2
```
Scrapy yapılandırması robots.txt uyumunu, AutoThrottle, düşük eşzamanlılık, sayfa/derinlik
sınırı, aynı-origin tarama ve her istekte hedef IP doğrulaması uygular. Scrapy Cloud veya
ücretli proxy/API servisi kullanılmaz. Scrapy paketi bu geliştirme ortamında kurulu olmadığı
için motorun gerçek ağ üzerinde çalıştırma testi henüz yapılmamıştır; yardımcı testler
opsiyonel bağımlılık olmadan çalışır.


## Playwright güvenlik katmanı
Browser mode her HTTP(S) isteğini (ana sayfa, yönlendirme ve alt kaynaklar dahil)
istek gönderilmeden önce URL/IP politikasıyla denetler. Local/private IP hedefleri
engellenir; indirme ve service worker desteği kapalıdır; render edilmiş HTML boyutu
sınırlandırılır. Chromium tarayıcı ikilisi bu geliştirme ortamında kurulu olmadığından
gerçek browser oturumu henüz uçtan uca doğrulanmamıştır.


## API dokümantasyonu keşfi
`discover_api_candidates(html, page_url)` yalnızca sayfada açıkça ilan edilmiş
OpenAPI/Swagger/service-description bağlantılarını bulur. `parse_openapi_spec(content)`
OpenAPI 3.x ve Swagger 2.0 JSON/YAML belgelerini yerel olarak ayrıştırır; HTTP isteği
göndermez ve endpoint'leri kendiliğinden çağırmaz. Böylece keşif ile veri toplama
aşamaları birbirinden ayrılır.


## Kalıcı tarama kuyruğu ve kaldığı yerden devam
Her HTTPX crawl artık SQLite içinde bir `run_id` ve URL bazlı iş kuyruğu oluşturur.
Durumlar: `pending`, `in_progress`, `done`, `error`, `blocked`. İşlem beklenmedik
şekilde kapanırsa sonraki `--resume` çağrısı `in_progress` işleri yeniden `pending`
durumuna alır. Aynı run içinde URL tekrar kuyruğa eklenmez.

Yeni tarama:
```bash
python -m wie.cli crawl https://example.org --max-pages 25 --max-depth 2 --run-id site-2026-01
```
Aynı taramayı sürdürme:
```bash
python -m wie.cli crawl https://example.org --max-pages 25 --max-depth 2 --run-id site-2026-01 --resume
```
`--max-pages` her çalıştırma çağrısındaki iş sayısı üst sınırıdır. `run_id` değerini
saklamak gerekir; SQLite dosyası silinirse kuyruk geçmişi de kaybolur.


## İçerik geçmişi ve değişiklik karşılaştırması
Her başarılı HTTPX sayfası `page_snapshots` tablosuna URL, zaman, hash, başlık ve
metinle kaydedilir. `list_snapshots()` sürümleri listeler; `diff_snapshots()` iki
sürüm arasında unified diff üretir. Aynı URL+hash ikinci kez tekrar kaydedilmez.

## İsteğe bağlı OCR
Taranmış/görüntü tabanlı PDF'ler için:
```bash
pip install -r requirements-ocr.txt
```
Ayrıca işletim sistemine Tesseract ve kullanılacak dil paketleri kurulmalıdır.
Örnek Python kullanımı:
```python
from wie.extract.ocr import ocr_pdf
result = ocr_pdf("scanned.pdf", languages="tur+eng", max_pages=20)
```
OCR varsayılan kurulumun parçası değildir; ücretsiz açık kaynak bileşenlerdir.
Tesseract veya dil paketi kurulu değilse fonksiyon açık hata verir. OCR bu aşamada
PDF belge çıkarıcısına otomatik bağlanmamıştır; ayrı ve isteğe bağlı bir fonksiyondur.


OCR artık belge çıkarımına isteğe bağlı bağlanabilir:
```python
from wie.extract.documents import extract_document
result = extract_document("scanned.pdf", ocr=True,
                          ocr_languages="tur+eng", ocr_max_pages=20)
```
Önce PDF'nin metin katmanı okunur; metin boşsa ve PDF şifreli değilse OCR fallback
devreye girer. `ocr=False` varsayılanı önceki davranışı korur.


## Yapılandırılmış Schema.org veri çıkarımı
HTML çıkarımı artık JSON-LD (`@graph` dahil), Microdata (`itemscope/itemprop`) ve
RDFa (`typeof/property`) biçimlerini normalize edilmiş entity kayıtlarına dönüştürür.
`extract_page()` sonucundaki `structured_entities` alanı; tür, ad, seçilmiş özellikler
ve kaynak biçimini taşır. Ham JSON-LD de geriye dönük uyumluluk için korunur.
Dış kaynak yüklenmez; script çalıştırılmaz. Çıkarım en fazla 200 tekil entity ile
sınırlandırılır.


## Kayıt normalizasyonu ve doğrulama
Kayıtlar SQLite'a yazılmadan önce `normalize_record()` üzerinden geçer:
HTTP(S) kaynak URL'si, timezone içeren ISO-8601 zamanı, SHA-256 hash'i, durum
alanı ve JSON'a çevrilebilir/boyut sınırı içindeki metadata doğrulanır. Başlık ve
metin Unicode NFC biçimine getirilir ve boşluklar sadeleştirilir. Ham HTML arşivi
değiştirilmeden ayrı tutulur.


## Kanıt zinciri ve bütünlük doğrulaması
Her başarılı sayfa toplama işlemi SQLite `evidence_events` tablosuna zincirlenmiş
bir olay olarak eklenir. Her olay bir önceki olayın SHA-256 hash'ini içerir.
`append_event()` yeni kayıt ekler; `verify_chain(database_path)` zinciri baştan
sona doğrular ve ilk bozulmuş olayın ID'sini raporlar. Bu mekanizma kurcalama
tespitine yardımcı olur; tek başına WORM depolama, dijital imza veya harici zaman
damgası değildir. Veritabanına ayrıcalıklı erişimi olan saldırgan zinciri yeniden
hesaplayabileceğinden üretimde dışarıya imzalı checkpoint alınmalıdır.


## Veri profilleme ve kalite raporu
`python -m wie.cli profile` yerel SQLite kayıtlarından toplam kayıt, durum dağılımı,
alan eksikleri, metin uzunlukları, tekrar hash grupları, kaynak alan adları, metadata
alanları, snapshot ve kanıt olayı sayılarını raporlar. Profil oluşturma ağ isteği
göndermez; yalnızca yerel veritabanını okur.


### Scrapy güvenlik düzeltmesi
Scrapy motorunda her istek ve yönlendirme hedefi hem genel IP/URL politikasından
hem de başlangıç origin kontrolünden geçirilir. 401, 403 ve 429 yanıtları tekrar
denenmez ve içerik çıkarımı yapılmadan ilgili dal durdurulur. Otomatik retry yalnızca
sınırlı 5xx kodları için etkinleştirilmiştir.


## Açık API dokümantasyonu keşfi ve ayrıştırma

Bir sayfanın HTML'inde açıkça ilan edilmiş OpenAPI/Swagger bağlantılarını keşfet:
```bash
python -m wie.cli api-discover https://example.org/docs
```

Aynı origin üzerindeki ve robots.txt tarafından izin verilen dokümantasyon dosyalarını
indirip yerel olarak ayrıştır:
```bash
python -m wie.cli api-discover https://example.org/docs --fetch-specs
```

Bu işlem yalnızca API dokümantasyon dosyasını okur; OpenAPI içindeki endpoint'lere
istek göndermez. Başka origin'e yönlendirme reddedilir. URL/IP güvenlik kontrolü,
yanıt boyutu sınırı ve 401/403/429 durdurma politikası uygulanır.
